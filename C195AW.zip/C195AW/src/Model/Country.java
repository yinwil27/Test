/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Wakiti
 */
public class Country {
    // same as firstdivision.model, Repeat Source generate for all combo boxes
    int countryid;
    String CountryName;

    public Country(int countryid, String CountryName) {
        this.countryid = countryid;
        this.CountryName = CountryName;
    }

    public int getCountryid() {
        return countryid;
    }

    public String getCountryName() {
        return CountryName;
    }
    
}
