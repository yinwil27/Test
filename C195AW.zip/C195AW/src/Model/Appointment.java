 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.time.LocalDate;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */
public abstract class Appointment {
     private int appointmentid;
      private String contactName;
    private String title;
    private String description;
    private String location;
    private int contact;
    private String type;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private String customerName;
    private String UserName;    
    private int customerid;
    private int userid;   
    
     public ObservableList<Record> associatedRecords = FXCollections.observableArrayList();
    public Appointment(int appointmentid, String ContactName, String customerName, String title, String description,
            String location, int contact,String type, LocalDate date, LocalTime startTime,
            LocalTime endTime, 
            String CustomerName, int customerid,  String UserName, int userid) {
        this.appointmentid = appointmentid; //complete
        this.contactName =contactName;  //complete
        this.title = title;//complete
        this.description= description;//complete
        this.location = location;//complete
        this.contact = contact;
        this.type = type;//complete
        this.startTime =startTime;//complete
        this.endTime =endTime;//complete
        this.date = date;
        this.customerid = customerid;//complete
        this.UserName= UserName;//complete
        this.userid = userid; //complete
        this.customerName= customerName;//complete
    
}
    
    
    public int getUserID() {
    return userid;
    }
    public void setPhoneNumber(){
    this.userid= userid;
    }
    public int getCustomerID(){
    return customerid;
    }
    public void setCustomerID() {
    this.customerid =customerid;
    }
    public String getContactName() {
    return contactName;
    }
    
    public void setContactName(){
    this.contactName = contactName;
    }
    
    public int getappointmentId() {
        return appointmentid;
    }
  public String getUserName() {
    return UserName;
    }
    
    public void setUserName(){
    this.UserName = UserName;
    }
    /**
     * @param id the id to set
     */
    public void setappointmentId(int appointmentid) {
        this.appointmentid = appointmentid;
    }

    /**
     * @return the name
     */
   
    public String getCustomerName() {
    return customerName;
    }
    
    public void setCustomerName(){
    this.customerName = customerName;
    }
    
    public String getTitle(){
    return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
    return description;
    }
    public void setDescription(String description) {
    this.description = description;
    }
    public String getLocation() {
    return location;
    }
    public void setLocation(String Location){
    this.location = location;
    }
    public String getType(){
    return type;
    }
    public void setType(String type) {
     this.type = type;
    }   
    public LocalTime getStartTime(){
    return startTime;
    }    
    public void setstartTime(LocalTime startTime){
    this.startTime =startTime;
    }   
      public LocalDate getDate(){
    return date;
    }    
    public void setDate(LocalDate date){
    this.date =date;
    }    
    public LocalTime getEndTime(){
    return endTime;
    }    
    public void setEndTime(LocalTime endTime){
    this.endTime =endTime;
    }    
    public void addAssociatedRecord(Record record) {
        associatedRecords.add(record);
    }
/**
     * deleteAssociatedRecord was created to power the remove Associated Record Button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public boolean deleteAssociatedRecord(Record record)
    {
        return associatedRecords.remove(record);
    }
public void setAssociatedRecord(ObservableList <Record> ap) {
        this.associatedRecords=ap;
    
    }
    /**
     *
     * @return
     */
    public ObservableList<Record> getAllAssociatedRecords() {
        return associatedRecords;
    }

}