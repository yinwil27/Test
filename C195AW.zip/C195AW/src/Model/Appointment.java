 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */
public class Appointment {
     private int Appointment_ID;
      private String contactName;
    private String Appointment_Name;
    private String description;
    private String location;
    private int contact;
    private String type;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private String customerName;
    private String UserName;    
    private int customerid;
    private int userid;   
    
     public ObservableList<Customer> associatedRecords = FXCollections.observableArrayList();
    public Appointment(int Appointment_ID, String Title, String Description, String Type, Time Start, Time End, String Created_By, String Location, int User_ID, int Contact_ID, Date Create_Date, int Customer_ID ) {
        this.Appointment_ID = Appointment_ID; //complete
        this.contactName =contactName;  //complete
        this.Appointment_Name = Appointment_Name;//complete
        this.description= description;//complete
        this.location = location;//complete
        this.contact = contact;
        this.type = type;//complete
        this.startTime =startTime;//complete
        this.endTime =endTime;//complete
        this.date = date;
        this.customerid = customerid;//complete
        this.UserName= UserName;//complete
        this.userid = userid; //complete
        this.customerName= customerName;//complete
    
}

    
       
    
    public int getUserID() {
    return userid;
    }
    public void setPhoneNumber(){
    this.userid= userid;
    }
    public int getCustomerID(){
    return customerid;
    }
    public void setCustomerID() {
    this.customerid =customerid;
    }
    public String getContactName() {
    return contactName;
    }
    
    public void setContactName(){
    this.contactName = contactName;
    }
    
    public int getappointmentId() {
        return Appointment_ID;
    }
  public String getUserName() {
    return UserName;
    }
    
    public void setUserName(){
    this.UserName = UserName;
    }
    /**
     * @param id the id to set
     */
    public void setappointmentId(int Appointment_ID) {
        this.Appointment_ID = Appointment_ID;
    }

    /**
     * @return the name
     */
   
    public String getCustomerName() {
    return customerName;
    }
    
    public void setCustomerName(){
    this.customerName = customerName;
    }
    
    public String getAppointment_Name(){
    return Appointment_Name;
    }
    public void setAppointment_Name(String Appointment_Name) {
        this.Appointment_Name = Appointment_Name;
    }
    public String getDescription() {
    return description;
    }
    public void setDescription(String description) {
    this.description = description;
    }
    public String getLocation() {
    return location;
    }
    public void setLocation(String Location){
    this.location = location;
    }
    public String getType(){
    return type;
    }
    public void setType(String type) {
     this.type = type;
    }   
    public LocalTime getStartTime(){
    return startTime;
    }    
    public void setstartTime(LocalTime startTime){
    this.startTime =startTime;
    }   
      public LocalDate getDate(){
    return date;
    }    
    public void setDate(LocalDate date){
    this.date =date;
    }    
    public LocalTime getEndTime(){
    return endTime;
    }    
    public void setEndTime(LocalTime endTime){
    this.endTime =endTime;
    }    
    public void addAssociatedRecord(Customer record) {
        associatedRecords.add(record);
    }
/**
     * deleteAssociatedRecord was created to power the remove Associated Customer Button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public boolean deleteAssociatedRecord(Customer record)
    {
        return associatedRecords.remove(record);
    }
public void setAssociatedRecord(ObservableList <Customer> ap) {
        this.associatedRecords=ap;
    
    }
    /**
     *
     * @return
     */
    public ObservableList<Customer> getAllAssociatedRecords() {
        return associatedRecords;
    }

}