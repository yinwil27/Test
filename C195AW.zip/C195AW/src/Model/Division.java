/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Wakiti
 */
public class Division {
    int divisionid;
    String DivisionName;
  public Division(int divisionid, String DivisionName) {
        this.divisionid = divisionid;
        this.DivisionName = DivisionName;
    }

    public int getDivisionid() {
        return divisionid;
    }

    public String getDivisionName() {
        return DivisionName;
    }
 @Override 
    public String toString()
            
    {
    return DivisionName;
    }
}



