/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import Model.Customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */

    
public class DBCustomers {

    public static ObservableList<Customer> GetAllCustomer() {
        ObservableList<Customer> DBListofCustomers = FXCollections.observableArrayList();
        try {
            String SQL = "Select Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID  FROM customers";
            //public Customer(int recordid, String name, String address, int postalCode, int phoneNumber, int divisionid) {
   
            PreparedStatement PS = DBConnection.getConnection().prepareStatement(SQL);
            ResultSet RS = PS.executeQuery();
            while (RS.next()) {
                int Customer_ID = RS.getInt("Customer_ID");
                String Customer = RS.getString("Customer_Name");
                 String Address = RS.getString("Address");
                  String Postal_Code = RS.getString("Postal_Code");
                  String Phone = RS.getString("Phone");
                  int Division_ID = RS.getInt("Division_ID");
                  
               Customer r = new Customer(Customer_ID, Customer, Address, Postal_Code, Phone, Division_ID);
                DBListofCustomers.add(r);
            }

        } catch (SQLException a) {
            a.printStackTrace();
        }

        return DBListofCustomers;
    }

}


