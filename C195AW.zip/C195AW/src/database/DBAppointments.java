/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import Model.Appointment;
import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */

    
public class DBAppointments {

    public static ObservableList<Appointment> GetAllAppointment() {
        ObservableList<Appointment> DBListofAppointments = FXCollections.observableArrayList();
        try {
            String SQL = "Select Appointment_ID, Title, Description, Type, Start, End,Created_By, Location,User_ID,Contact_ID,Create_Date, Customer_ID FROM appointments, customers, users, contacts Where. // grab stuff from phone";
  /*Appointment(int Appointment_ID, String Created_By,  String Title, String Description,
            String Location, int Contact_ID, String Type, LocalDate Create_Date, LocalTime Start,
            LocalTime End, 
             int Customer_ID,  int User_ID)  */
            PreparedStatement PS = DBConnection.getConnection().prepareStatement(SQL);
            ResultSet RS = PS.executeQuery();
            while (RS.next()) {
                int Appointment_ID = RS.getInt("Appointment_ID");
                String Title = RS.getString("Title");
                String Description = RS.getString("Description");
                String Type = RS.getString("Type");
                Timestamp Start = RS.getTimestamp("Start");
                LocalDateTime StartLDT = Start.toLocalDateTime();//timezone conversion
                LocalTime StartTime = StartLDT.toLocalTime();
                LocalDate StartDate = StartLDT.toLocalDate();
                Timestamp End = RS.getTimestamp("End");// Repeat everything I did on START
                
                LocalDateTime EndLDT = End.toLocalDateTime();//timezone conversion
                LocalTime EndTime = EndLDT.toLocalTime();
                LocalDate EndDate = EndLDT.toLocalDate();
                String Created_By = RS.getString("Created_By");
                String Location = RS.getString("Location");
                int User_ID = RS.getInt("User_ID");
                int Customer_ID = RS.getInt("Customer_ID");
                int Contact_ID = RS.getInt("Contact_ID");
                Date Create_Date = RS.getDate("Create_Date");
  //              Appointment a = new Appointment(Appointment_ID, Title, Description, Type, Start, End, Created_By, Location,User_ID,Contact_ID, Create_Date, Customer_ID );
                //(int Appointment_ID, String Created_By/*ContactName*/,  String Title, String Description, String Location, int Contact_ID, String Type, Date Create_Date, Time Start, Time End, int Customer_ID,  int User_ID)
//               DBListofAppointments.add(a);
            }

        } catch (SQLException a) {
            a.printStackTrace();
        }

        return DBListofAppointments;
    }

}


