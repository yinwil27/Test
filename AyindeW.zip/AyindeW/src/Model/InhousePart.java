/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 * Supplied class Part.java
 */
/**
 *
 * @author Ayinde
 **   This Class creates an InhousePart for the Add Product/ModifyProduct Screen.JAVA SE should work if you update any feature in this page
 */
public class InhousePart extends Part {

    private int machineId;

    public InhousePart(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;

    }

   
    /*public InhousePart(int i, String starbucks, int i0, double d) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/

    /**
     *  /**
     *  this starts the Inhouse Part piece, This caused a runtime error when I was building the logic  to create an inhouse Part. I fixed it by making sure my syntax was correct, Id with one capital.   a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
•    * a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     *
     * @return the id
     **Update should work fine with Java SE
     ** Challenges This caused a runtime error when I was building the logic  to create an inhouse Part. I fixed it by making sure my syntax was correct, Id with one capital. 
     */
    public int getMachineId(){
    return machineId;
    }
     /**
     *  setMachineId, I used this to set everything in the Inhouse Part, same basics as the getMachineId.  A detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    
    public void setMachineId(int machineId){
    this.machineId=machineId;    }
}
