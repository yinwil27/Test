/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 ** Description This Creates an Inventory Class.JAVA SE should work if you update any feature in this page
 ** @author Ayinde
 */
public class Inventory {
      /**
     ** partGen was used to generate a unique Id for Parts, otherwise we had a logic error  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  **a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
   public static int partGen;
     /**
     *  productGen same basics as the partGen, creating a unique ID  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
   public static int productGen;
     /**
     *   allParts was an observable list created to work with Modify Part a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Part> allParts = FXCollections.observableArrayList();
     /**
     *   allProducts was an observable list created to work with Modify Product a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Product> allProducts = FXCollections.observableArrayList();
     /**
     *  lookupPart was a method  created to work with the Search functions,  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    private static ObservableList<Part> lookupPart = FXCollections.observableArrayList();
      /**
     *   lookupProduct was a method created to work with search functions to avoid logic errors a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     private static ObservableList<Product> lookupProduct = FXCollections.observableArrayList();
    public static void AddPart(Part Newpart) {
        allParts.add(Newpart);
    }

    public static void AddProduct(Product NewProduct) {
        allProducts.add(NewProduct);
    }

    public static Part lookupPart(int partPiece) {
      if (!allParts.isEmpty()) {
            for (int i = 0; i < allParts.size(); i++) {
                if (allParts.get(i).getId() == partPiece) {
                    return allParts.get(i);
                }
            }

        }
        return null;
    }


//{

      //  for (Part cm : allParts) {
        //    if (cm.getId() == (partPiece)) {                     

          //      return cm;
            //}
            
       // }
       // return null;
    //}
    
    
    
    
    
    
    
    
    
        /**
         * lookup part required a retool,because it kept causing a runtime error, I fixed it using the made up "eo" variable to get the search working
         * should work with Java SE 
         * @param partName
         * @return
         */
    public static final ObservableList<Part> lookupPart (String partName) {
         ObservableList<Part> eo = FXCollections.observableArrayList();
           

        for (Part dn : allParts)
           {
        if (partName.compareTo(dn.getName())==0)
                { eo.add(dn);
                     }
        }   
        return eo;
    }
    
    



public static Product lookupProduct(int productid) {
        for(Product cm: allProducts) {
           if(cm.getId() == productid){
               
           return cm;}
        }return null;}

/**
         *
         * @param productName
         * @return
         */

 public static ObservableList<Product> lookupProduct(String productName) {
        return allProducts.sorted();   
} 
   /**
     *  updatePart, created to power the Modify Part function a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }
  /**
     *  updateProducts was a method created to power Modify Product a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static void updateProduct(int index, Product selectedProduct) {
        allProducts.set(index, selectedProduct);
    }
  /**
     * deletePart was created to power the Drelte Part button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static boolean deletePart(Part selectedPart){
        return allParts.remove(selectedPart);
}
/**
     *   deleteProduct was created to power the Delete Product button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static boolean deleteProduct(Product selectedProduct){
        return allProducts.remove(selectedProduct);
}
/**
     *  GetAllProducts was created to work with the Modify Product field detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
public static ObservableList<Product> GetAllProducts(){
           return allProducts;
               }
/**
     *   GetAllParts was created to work with Modify Part detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static ObservableList<Part> GetAllParts() {
        return allParts; //To change body of generated methods, choose Tools | Templates.
    }
    
    /**
     *   works with partGen detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     public static int getpartGen(){
        partGen++;
        return partGen;
    }
     /**
     *   works with partGen detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
     public static int getproductGen(){
        productGen++;
        return productGen;
    }
}







    /**/
