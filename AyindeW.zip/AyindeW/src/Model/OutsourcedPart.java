package Model;


        
/**
* Supplied class Part.java 
 */

/**
 ** Description This Class creates an Outsourced Part.JAVA SE should work if you update any feature in this page
 * @author Ayinde
 */
public class OutsourcedPart extends Part{
   
    private String companyName;
   
    public OutsourcedPart(int id, String name, double price, int stock, int min, int max, String companyName) {
      super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }
    
    /**
     * @return the id
     * *Update should work fine with Java SE
     ** Challenges This caused a runtime error when I was building the logic  to create an outsourced Part. I fixed it by making sure my syntax was correct, companyName with one capital. 
     */
public String getCompanyName(){
    return companyName;
    }
/**
     *  set company name is the same as get Make sure to capitalize correctly or you'll get an error. detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public void setCompanyName(String companyName){
    this.companyName=companyName;    }
    /**
     * @return the id
     */
  
    
}