package Model;


        
/**
* Supplied class Part.java 
 */

/**
 *@Description This Class creates an Outsourced Part
 * @author Ayinde
 */
public class OutsourcedPart extends Part{
   
    private String companyName;
   
    public OutsourcedPart(int id, String name, double price, int stock, int min, int max, String companyName) {
      super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }
    
    /**
     * @return the id
     *@Update should work fine with Java SE
     * @Challenges This caused a runtime error when I was building the logic  to create an outsourced Part. I fixed it by making sure my syntax was correct, companyName with one capital. 
     */
public String getCompanyName(){
    return companyName;
    }
    public void setCompanyName(String companyName){
    this.companyName=companyName;    }
    /**
     * @return the id
     */
  
    
}