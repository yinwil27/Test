/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ayindew;

import Model.InhousePart;
import Model.Inventory;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Ayinde
 * * AyindeW Kickoff, I used this to open the IMS, and add a default part to help debug  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
** Java SE should work  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application :
    
 */
public class AyindeW extends Application {

    private static void print(InhousePart Part1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
     /**
     *  Kickoff, I used this to open the IMS, otherwise a logic error.  A detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
        
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments, I used this to test the error I was getting in my add part section  a detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to

•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static void main(String[] args) {
      InhousePart Part1= new InhousePart(1,"Java",2.0,12,1,100,4132 );
      Inventory.AddPart(Part1);
      Inventory.AddPart(new InhousePart(2,"Folgers",3.7, 13,1,100,4132));
      Inventory.partidGeneration = 2;
      
        launch(args);
      
    }
    
}
