/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;
/**
 * This class Creates an Inventory Management System Scene Function.
 */
/**
 *
 * @author Ayinde
 */
class Scene {
    /**
     * @Challenges I just created this to get out of a runtime error, Don't touch!
     * @updates Should work fine with Java SE
     */
}
