/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;
/**
 * This class Creates an Inventory Management System Main Screen.JAVA SE should work if you update any feature in this page
 */
import Model.Inventory;
import Model.Part;
import Model.Product;
import Model.InhousePart;
import static Model.Inventory.deletePart;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Pane;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.Inventory;
import static Model.Inventory.GetAllParts;
import static Model.Inventory.GetAllProducts;
import Model.Part;
import Model.Product;
import static java.lang.Double.max;
import static java.lang.Integer.max;
import View_Controller.ModifyPartController;

/**
 * FXML Controller class
 *
 * @author Ayinde
 */
/*** This class Creates an Inventory Management System Main Screen.*/
public class MainScreenController implements Initializable {

    public TableView<Product> ProductsTable;
    @FXML
    public Button addProduct;
    @FXML
    public Button updateProduct;
    @FXML
    public Button deleteProduct;
    @FXML
    public TableView<Part> PartsTable;
    @FXML
    public Button addPart;
    @FXML
    public Button updatePart;
    @FXML
    public Button deletePart;
    @FXML
    public Button Exit;

    @FXML
    private TableColumn<Product, Float> AllProductID;
    @FXML
    private TableColumn<Product, String> AllProductName;
    @FXML
    private TableColumn<Product, Integer> ProductInv;
    @FXML
    private TableColumn<Product, Double> ProductPC;
    @FXML
    private TableColumn<Part, Integer> allPartsID;
    @FXML
    private TableColumn<Part, String> allPartName;
    @FXML
    private TableColumn<Part, Integer> PartsInv;
    @FXML
    private TableColumn<Part, Double> PartsPC;
    @FXML
    private TextField productSearch;
    @FXML
    private TextField partSearch;
    private Object result;

    private static Part modifyPart;
    private static int modifyPartIndex;
    private static Product modifyProduct;
    private static int modifyProductIndex;
/**
     * @param args partToModifyIndex was created to get around the logical error of moving a part to different screens detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static int partToModifyIndex() {
        return modifyPartIndex;
    }
/**
     * @param args  producttoModifyIndex , same deal as partToModifyIndex, created to get around the error of moving parts from place to place detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static int productToModifyIndex() {
        return modifyProductIndex;
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        allPartsID.setCellValueFactory(new PropertyValueFactory<>("id"));
        allPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        PartsInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PartsPC.setCellValueFactory(new PropertyValueFactory<>("price"));
        PartsTable.setItems(Inventory.GetAllParts());

        /* AllParts.add(new InhousePart (3, "Starbucks", 17, 35.6));*/
        ProductsTable.setItems(Inventory.GetAllProducts());
        AllProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        AllProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProductInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProductPC.setCellValueFactory(new PropertyValueFactory<>("price"));
        // updatePartTable();
        // updateProductTable();
    }
/**
     * @param args  getModifyPart was created to power the  Modify Part button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public static Part getModifyPart() {
        return modifyPart;
    }

    public void setModifyPart(Part modifyPart) {
        MainScreenController.modifyPart = modifyPart;
    }

    public void setModifyProduct(Product modifyProduct) {
        MainScreenController.modifyProduct = modifyProduct;
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @FXML
    public void addProduct(ActionEvent event) throws IOException {

        Parent AddProductScene = FXMLLoader.load(getClass().getResource("/View_Controller/AddProduct.fxml"));
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

        Scene scene = new Scene(AddProductScene);

        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void updateProduct(ActionEvent event) throws IOException {

        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View_Controller/ModifyProduct.fxml"));
            Parent ModifyProduct = loader.load();
            //modifyProductIndex = GetAllProducts().indexOf(modifyProduct);

            
            /**
             * @Challenges I had to create multiple "pass ins" in order to get this to work,huge logic errors initially I tried an index
             * @Update should work fine with Java SE
             */
            ModifyProductController Cuzzo = loader.getController();
            Cuzzo.toughWork(ProductsTable.getSelectionModel().getSelectedItem());
            
            ModifyProductController Slime = loader.getController();
            Slime.slim(ProductsTable.getSelectionModel().getSelectedItem());
                   

            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(ModifyProduct);

            stage.setScene(scene);
            stage.show();

            modifyProduct = ProductsTable.getSelectionModel().getSelectedItem();
            setModifyProduct(modifyProduct);

        }
    }

    @FXML
    public void deleteProduct(ActionEvent event) throws IOException {

        Product product = ProductsTable.getSelectionModel().getSelectedItem();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirm Product Delete!");
        alert.setContentText("Are you sure you want to delete this product? It may be attached to a part. ");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            System.out.println("No takebacks.");
            Inventory.deleteProduct(product);
            // return remove;
        } else {
            System.out.println("No takebacks");
        }
        if (product != null) {

        }

    }

    @FXML
    public void addPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/AddPart.fxml"));
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void deletePart(ActionEvent event) throws IOException {
        Part part = PartsTable.getSelectionModel().getSelectedItem();

        
        
        
        
        
        
        
         
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirm Part Delete!");
        alert.setContentText("Are you sure you want to delete this part. ");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            System.out.println("No taakebacks.");
            Inventory.deletePart(part);
            // return remove;
        } else {
            System.out.println("No takebacks");
        }
        if (part != null) {

        }
        
        
        
        
        
        
        
        

    }

    /**
     *
     * @param event
     * @throws java.io.IOException
     * @
     */
    @FXML
    public void Exit(ActionEvent event) {
        
        
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initModality(Modality.NONE);
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
             Stage stage;
        stage = (Stage) Exit.getScene().getWindow();
        stage.close();
           
        } else {
            System.out.println("You clicked Exit. Please complete info.");
        }
        
        
        
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @FXML

    public void updatePart(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/ModifyPart.fxml"));
        Parent ModifyPart = loader.load();
        //modifyPartIndex = GetAllParts().indexOf(modifyPart);

        ModifyPartController FriendofFamily = loader.getController();
        FriendofFamily.gruntWork(PartsTable.getSelectionModel().getSelectedItem());

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(ModifyPart);

        stage.setScene(scene);
        stage.show();

        modifyPart = PartsTable.getSelectionModel().getSelectedItem();
        setModifyPart(modifyPart);

    }
    //access the controller, call method from ModifyPC        ModifyPartController nameofController= loader.getController();
    //  controller.nameofmethod(PartTable.getSelectionModel().getSelectedItem());

    @FXML

    public void lookupProduct(ActionEvent event) throws IOException {
        //if partSearch is empty, update part table with all parts
        if (!productSearch.getText().trim().isEmpty()) {
            try {
                int search = Integer.parseInt(productSearch.getText());
                for (Product p : Inventory.allProducts) {
                    if (p.getId() == search) {
                        ProductsTable.getSelectionModel().select(p);
                    }
                }
            } catch (NumberFormatException e) {
                String search = (partSearch.getText());
                for (Product p : Inventory.allProducts) {
                    if (p.getName().equals(search)) {
                        ProductsTable.getSelectionModel().select(p);
                    }
                }

            }

        } else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Products Found");
            alert.setContentText("Please Try Again with a product from the list");
            alert.showAndWait();
            ProductsTable.getSelectionModel().clearSelection();
        }
    }

    @FXML
    public void lookupPart(ActionEvent event) throws IOException {
        //if partSearch is empty, update part table with all parts
        if (!partSearch.getText().trim().isEmpty()) {
            try {
                int search = Integer.parseInt(partSearch.getText());
                for (Part p : Inventory.allParts) {
                    if (p.getId() == search) {
                        PartsTable.getSelectionModel().select(p);
                    }/*else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error finding Part ");
            alert.setContentText("When searching for a p part from the list");
            alert.showAndWait();
            PartsTable.getSelectionModel().clearSelection();
                }*/
                }} 
                catch (NumberFormatException e) {
                String search = (partSearch.getText());
                for (Part p : Inventory.allParts) {
                    if (p.getName().equals(search)) {
                        PartsTable.getSelectionModel().select(p);
                    }/*else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error finding Part ");
            alert.setContentText("Please Try again with a part from the list");
            alert.showAndWait();
            PartsTable.getSelectionModel().clearSelection();
                }*/

            }

         
        }
    }else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error finding Part ");
            alert.setContentText("Please Type again with a part from the list");
            alert.showAndWait();
PartsTable.getSelectionModel().clearSelection();
}
}} 
