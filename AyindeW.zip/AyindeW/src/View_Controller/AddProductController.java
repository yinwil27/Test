/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;
/**
 * This class Creates an Inventory Management System Add Product Screen.JAVA SE should work if you update any feature in this page
 */
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.Inventory;
import Model.Part;
import Model.Product;
import Model.Product;
import static java.lang.Double.max;
import static java.lang.Integer.max;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;


/*
 * FXML Controller class
 *
 * @author Ayinde
 */
 /*


 */
public class AddProductController implements Initializable {

    public ObservableList<Part> minuteParts = FXCollections.observableArrayList();
    Product NewGuy;
    private String exceptionMessage = new String();
    private int productID;

    @FXML
    private TextField AddProductNameField;
    @FXML
    private TextField AddProductPriceField;
    @FXML
    private TextField AddProductInvField;
    @FXML
    private TextField AddProductMinField;
    @FXML
    private TextField AddProductMaxField;
    private TextField AddProductDeleteSearchField;
    @FXML
    private TextField AddProductSearchField;
    @FXML
    private TableView<Part> AddProductAddTable;
    @FXML
    private TableColumn<Part, Integer> ProductIDCol;
    
    @FXML
    private TableColumn<Part, Integer> InvProductCol;
    @FXML
    private TableColumn<Part, Double> PriceProductCol;
    @FXML
    private TableColumn<Part, Integer> DelIDCol;
    @FXML
    private TableColumn<Part, String> DelNameCol;
    @FXML
    private TableColumn<Part, Integer> DelInvCol;
    @FXML
    private TableColumn<Part, Double> DelPriceCol;
    @FXML
    private TableView<Part> AddProductDeleteTable;
    @FXML
    private Button AddProductButton;
    @FXML
    private Text ProductFormID;
    @FXML
    private Text ProductNameField;
    @FXML
    private Button SaveButton;
    @FXML
    private Button CancelButton;
    @FXML
    private Button RemoveButton;
    @FXML
    private TextField AddProductFormIDField;
    @FXML
    private TableColumn<Part, String> NameProductCol;
   public String blank = "";
   int productid;
   
   
    public AddProductController() {
        /**
         ** @Challenges I had to make sure NewGuy was passed in to my APSave,logic errors otherwise, I kept reading over it, but I fixed it by making sure I added it only once, and just summoning it every other time
         ** @Updates should work fine with Java SE
         */
        this.NewGuy = new Product(5,"",0.0,0,0,0);
    }

    void APClearSearch(ActionEvent event) {

        AddProductSearchField.setText("");
    }

    void RPClearSearch(ActionEvent event) {

        AddProductDeleteSearchField.setText("");
    }

    @FXML
    void APSearchPartAddBtn(ActionEvent event) {

        String searchPart = AddProductSearchField.getText();

        
        
        
        
        if (!AddProductSearchField.getText().trim().isEmpty()) {
            try {
                int search = Integer.parseInt(AddProductSearchField.getText());
                for (Part p : Inventory.allParts) {
                    if (p.getId() == search) {
                        AddProductAddTable.getSelectionModel().select(p);
                    }
                }
            } catch (NumberFormatException e) {
                String search = (AddProductSearchField.getText());
                for (Part p : Inventory.allParts) {
                    if (p.getName().equals(search)) {
                        AddProductAddTable.getSelectionModel().select(p);
                    }
                }

            }

        }else{Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Parts Found");
            alert.setContentText("Please Try Again with a part from the list");
            alert.showAndWait();
            AddProductAddTable.getSelectionModel().clearSelection();
        }
        
        
        
        
        
    }

    @FXML
    void AddProductBtn(ActionEvent event) {
        Part part = AddProductAddTable.getSelectionModel().getSelectedItem();
        //NewGuy.minuteParts.add(part);
        NewGuy.addAssociatedPart(part);
        AddProductDeleteTable.setItems(NewGuy.getAllAssociatedParts());
        AddProductDeleteTable.refresh();
        
//Inventory.AddPart(iHpart2);

//Set Items Table
    }

    void APSearchPartDeleteBtn(ActionEvent event) {

        //needs work
    }

    @FXML
    void APRemove(ActionEvent event) {

        Part part = AddProductDeleteTable.getSelectionModel().getSelectedItem();
        

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirm Current Part Delete!");
        alert.setContentText("Are you sure you want to delete part ");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            System.out.println("Part delete button clicked.");
            NewGuy.deleteAssociatedPart(part);
           //return remove;
        } else {
            System.out.println("Cancel clicked.");
        }
        //return false;
   
            }
@FXML
   void APSave(ActionEvent event) throws IOException { 
       try {
           
            
            if (AddProductNameField.equals(blank)){
                   Alert alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Error");
                   alert.setHeaderText("Product must contain a Name.");
                   alert.showAndWait();}
            if (AddProductInvField.equals(blank)){
                   Alert alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Error");
                   alert.setHeaderText("Product must contain at least one Inv/Stock.");
                   alert.showAndWait();} 
             if (AddProductMinField.equals(blank)){
                   Alert alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Error");
                   alert.setHeaderText("Product must contain a Number in the Min.");
                   alert.showAndWait();} 
              if (AddProductMaxField.equals(blank)){
                   Alert alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Error");
                   alert.setHeaderText("Product must contain a number in the max field.");
                   alert.showAndWait();} 
               else {
                  
           String productName = AddProductNameField.getText();
           int productInv = Integer.parseInt(AddProductInvField.getText());
           String productPrice = AddProductPriceField.getText();
           int productMin = Integer.parseInt(AddProductMinField.getText());
           int productMax = Integer.parseInt(AddProductMaxField.getText());
       if (exceptionMessage.length() > 0) {
           Alert alert = new Alert(Alert.AlertType.INFORMATION);
           alert.setTitle("Error Adding Product");
           alert.setHeaderText("Error");
           alert.setContentText(exceptionMessage);
           alert.showAndWait();
           exceptionMessage = "";
       } else {
           System.out.println("Product name: " + productName);
           NewGuy.setId(productID);
           NewGuy.setName(productName);
           NewGuy.setPrice(Double.parseDouble(productPrice));
           NewGuy.setStock(productInv);
           NewGuy.setMin(productMin);
           NewGuy.setMax(productMax);
           
           //   newProduct.setProductParts();
       if (productMin > productMax) {
Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Confirmation");
               alert.setHeaderText("You Sure?!");
               alert.setContentText("Issue with Min/Max, please modify");
               Optional<ButtonType> result = alert.showAndWait();
               return;
       }
       if (productMin > productInv) {
Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Confirmation");
               alert.setHeaderText("You Sure?!");
               alert.setContentText("Issue with Min being smaller than INV/Stock, please modify");
               Optional<ButtonType> result = alert.showAndWait();
               return;
                }
       if (productInv > productMax) {
Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Confirmation");
               alert.setHeaderText("You Sure?!");
               alert.setContentText("Issue with stock being larger than max, please modify");
               Optional<ButtonType> result = alert.showAndWait();
               return;
               }
           Inventory.AddProduct(NewGuy);
           Parent productsSave = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
           Scene scene = new Scene(productsSave);
           Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
           window.setScene(scene);
           window.show();
       }
   }}
           catch (NumberFormatException e) {
           Alert alert = new Alert(Alert.AlertType.INFORMATION);
           alert.setTitle("Error");
           alert.setHeaderText("Error Adding Product");
           alert.setContentText("Form contains incorrectly added fields. Stock, Price, Min, and Max Should be numbers");
           alert.showAndWait();
       }
   }
            
 
            
    @FXML
    void Cancel(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave" + AddProductNameField.getText() + "?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {

            Parent partsCancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(partsCancel);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } else {
            System.out.println("You clicked cancel. Please complete part info.");
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        ProductIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        NameProductCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        InvProductCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PriceProductCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        AddProductAddTable.setItems(Inventory.GetAllParts());

        //Ask how to get the piece to the right spot, the part shoould transfer when I add
        //     AddProductDeleteTable.setItems(Inventory.GetAllParts());
             DelIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
           DelNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
           DelInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
          DelPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
           
           productID = Inventory.getproductGen();
    }

}
