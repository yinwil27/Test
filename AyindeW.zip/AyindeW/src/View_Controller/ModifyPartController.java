/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;
/**
 * This class Creates an Inventory Management System Modify Part Screen.
 */
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.InhousePart;
import Model.OutsourcedPart;
import Model.Inventory;
import Model.Part;

import static Model.Inventory.GetAllParts;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Model.InhousePart;
import Model.Inventory;
import Model.OutsourcedPart;
import Model.Part;
import static View_Controller.MainScreenController.partToModifyIndex;
import static java.lang.Double.min;
import static java.lang.Integer.max;
import static java.lang.Integer.min;

/**
 * FXML Controller class
 *
 * @author Ayinde
 */
public class ModifyPartController implements Initializable {

    @FXML
    private ToggleGroup ModPart;
    @FXML
    private RadioButton outSourced2;
    private Text machineIDlabel;
    @FXML
    private RadioButton inHouse2;
    private Text machineIDlabel2;
    @FXML
    private Text machineidlabel;

    @FXML
    private TextField machineidfield;
    @FXML
    private Button Save;
    @FXML
    private Button Cancel;
    @FXML
    private TextField ModPartIDField;
    @FXML
    private TextField ModPartNameField;
    @FXML
    private TextField ModPartPriceField;
    @FXML
    private TextField ModPartMaxField;
    @FXML
    private TextField ModPartInvField;
    @FXML
    private TextField ModPartMinField;

    int partIndex;
    private String exceptionMessage = new String();
    private int partID;

    public ModifyPartController() {
        this.partIndex = partToModifyIndex();
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    /**
     * @Challenges, continuation of what I did within updatePart , make sure this is untouched, otherwise there will be a runntime error
     * @Updates Should work fine with Java SE
     * @param Dyn 
     */
    public void gruntWork(Part Dyn) {
        partIndex = Inventory.GetAllParts().indexOf(Dyn);
        partID = Dyn.getId();
        ModPartIDField.setText(Integer.toString(partID));
        ModPartNameField.setText(Dyn.getName());
        ModPartInvField.setText(Integer.toString(Dyn.getStock()));
        ModPartPriceField.setText(Double.toString(Dyn.getPrice()));
        ModPartMinField.setText(Integer.toString(Dyn.getMin()));
        ModPartMaxField.setText(Integer.toString(Dyn.getMax()));

        if (Dyn instanceof InhousePart) {

            InhousePart workAround = (InhousePart) Dyn;
            machineidlabel.setText("Machine ID");
            machineidfield.setText(Integer.toString(workAround.getMachineId()));
            inHouse2.setSelected(true);
//at View_Controller.ModifyPartController.gruntWork(ModifyPartController.java:100)  ask foor help
//	at View_Controller.MainScreenController.updatePart(MainScreenController.java:268)
        } else if (Dyn instanceof OutsourcedPart) {
            OutsourcedPart workAround = (OutsourcedPart) Dyn;
            machineidfield.setText(workAround.getCompanyName());
            //   machineidfield.setText(((OutsourcedPart) GetAllParts().get(partIndex)).getCompanyName());
            machineidlabel.setText("Company Name");
            outSourced2.setSelected(true);
        }
    }

    /**
     *
     * @return
     */
    public RadioButton getinHouse2() {
        return inHouse2;
    }

    @FXML
    private void OnoutSourced2(ActionEvent event) {
        machineidlabel.setText("Company Name");
    }

    @FXML
    private void oninHouse2(ActionEvent event) {
        machineidlabel.setText("Machine ID");
    }

    @FXML
    public void Cancel(ActionEvent event) throws IOException {

        
        
          
         Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave?");
        Optional<ButtonType> result = alert.showAndWait();

        
        if (result.get() == ButtonType.OK) {

            Parent partsCancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(partsCancel);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } else {
            System.out.println("You clicked cancel. Please complete part info.");
        }
        
        
        
        

    }

    @FXML
    public void Save(ActionEvent event) throws IOException {
try{
        int id = partID;
        String name = ModPartNameField.getText();
        double price = Double.parseDouble(ModPartPriceField.getText());
        int stock = Integer.parseInt(ModPartInvField.getText());
        int min = Integer.parseInt(ModPartMinField.getText());
        int max = Integer.parseInt(ModPartMaxField.getText());

        if (ModPart.getSelectedToggle().equals(inHouse2)) {
            Part iHpart2 = new InhousePart(id, "", 0.0, 0, 0, 00, 0000);
            if (!ModPartNameField.getText().isEmpty()) {
                //repeat 5 times 
                iHpart2.setName(ModPartNameField.getText());
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Name is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartInvField.getText().isEmpty()) {
                //repeat 4 times 
                iHpart2.setStock(Integer.parseInt(ModPartInvField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartPriceField.getText().isEmpty()) {
                //repeat 3 times 
                iHpart2.setPrice(Double.parseDouble(ModPartPriceField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Price is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartMaxField.getText().isEmpty()) {
                //repeat 2 times 
                iHpart2.setMax(Integer.parseInt(ModPartMaxField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Max is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartMinField.getText().isEmpty()) {
                //repeat 1 times 
                iHpart2.setMin(Integer.parseInt(ModPartMinField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Min is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!machineidfield.getText().isEmpty()) {
                //done 
                ((InhousePart) iHpart2).setMachineId(Integer.parseInt(machineidfield.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Field is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            // create new exception for if min/max is empty

            if (min > max) {
Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                
            }
            if (stock < min) {
Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue withstock being smaller than min, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                
            }
            if (stock > max) {
Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue stock is larger than , please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
               
            }
            Inventory.updatePart(partIndex, iHpart2);
            Parent Cancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(Cancel);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        }

        if (ModPart.getSelectedToggle().equals(outSourced2)) {
            Part oSpart2 = new OutsourcedPart(id, "", 0.0, 0, 0, 00, "xx");
            if (!ModPartNameField.getText().isEmpty()) {
                //repeat 5 times 
                oSpart2.setName(ModPartNameField.getText());
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Name is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartInvField.getText().isEmpty()) {
                //repeat 4 times 
                oSpart2.setStock(Integer.parseInt(ModPartInvField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartPriceField.getText().isEmpty()) {
                //repeat 3 times 
                oSpart2.setPrice(Double.parseDouble(ModPartPriceField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Price is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartMaxField.getText().isEmpty()) {
                //repeat 2 times 
                oSpart2.setMax(Integer.parseInt(ModPartMaxField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Max is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!ModPartMinField.getText().isEmpty()) {
                //repeat 1 times 
                oSpart2.setMin(Integer.parseInt(ModPartMinField.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Min is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!machineidfield.getText().isEmpty()) {
                //done 
                ((OutsourcedPart) oSpart2).setCompanyName((machineidfield.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Field is Empty/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }

            if (min > max) {
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
              
            }
            if (stock < min) {

 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is smaller than minimum, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                
            }
            if (stock > max) {

 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is larger than max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                
            }

            Inventory.updatePart(partIndex, oSpart2);

            Parent Cancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(Cancel);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();

        }

    }catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error Modifying Product");
            alert.setContentText("Form contains incorrectly added fields. Stock, Price, Min, and Max Should be numbers");
            alert.showAndWait();
        }
    }
    private void UpdateTable() throws IOException {

    }

}
