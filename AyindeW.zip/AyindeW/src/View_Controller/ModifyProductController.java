/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package View_Controller;
/**
 ** @param Controller Creates an Inventory Management System Modify Product Screen.JAVA SE should work if you update any feature in this page
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable; 

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.Inventory;
import static Model.Inventory.GetAllParts;
import static Model.Inventory.GetAllProducts;
import Model.Part;
import Model.Product;
import static View_Controller.MainScreenController.productToModifyIndex;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;



/**
 * FXML Controller class
 *
 * @author Ayinde
 */

public class ModifyProductController implements Initializable {

    public ObservableList<Part> bottomTableParts = FXCollections.observableArrayList();
    Product TemporaryProduct = new Product();
    private int productIndex = productToModifyIndex();
    private String exceptionMessage = new String();
    private int productID;

    @FXML
    private TextField ModProductsIDField;
    @FXML
    private TextField ModProductsMinField;
    @FXML
    private TextField ModProductsMaxField;
    @FXML
    private TextField ModProductsInvField;
    @FXML
    private TextField ModProductsNameField;
    @FXML
    private TextField ModProductsPriceField;
    @FXML
    private TextField ModProductAddPartSearchField;
    private TextField ModProductDeletePartSearchField;
    @FXML
    private TableView<Part> MPAT;
    @FXML
    private TableColumn<Part, Integer> ModProductPartIDCol;
    @FXML
    private TableColumn<Part, String> ModProductPartNameCol;
    @FXML
    private TableColumn<Part, Integer> ModProductPartInvCol;
    @FXML
    private TableColumn<Part, Double> ModProductPartPriceCol;
    @FXML
    public TableView<Part> ModProductDeleteTable;
    @FXML
    private TableColumn<Part, Integer> ModProductDelPartIDCol;
    @FXML
    private TableColumn<Part, String> ModProductDelPartNameCol;
    @FXML
    private TableColumn<Part, Integer> ModProductDelPartInvCol;
    @FXML
    private TableColumn<Part, Double> ModProductDelPartPriceCol;
    @FXML
    private Button ModProdCancel;
    @FXML
    private Button ModProdSaved;
    @FXML
    private Button RemoveButton;
    
    

    
    public void bringFromAddProduct(Product Dyn){
        TemporaryProduct = Dyn;
         productIndex = Inventory.GetAllProducts().indexOf(Dyn);
        productID = GetAllProducts().get(productIndex).getId();
        ModProductsIDField.setText("Part ID autoset to: " + Dyn.getId());
        ModProductsNameField.setText(Dyn.getName());
        ModProductsInvField.setText(Integer.toString(Dyn.getStock()));
        ModProductsPriceField.setText(Double.toString(Dyn.getPrice()));
        ModProductsMinField.setText(Integer.toString(Dyn.getMin()));
        ModProductsMaxField.setText(Integer.toString(Dyn.getMax()));
        ModProductDeleteTable.setItems(Dyn.getAllAssociatedParts());  
      
    }
   // public void slim (Product Dyn){
        //MPAT.setItems(Inventory.GetAllParts());
     
   // }
 
    void ClearSearchAdd(ActionEvent event) {
      updatePartTable();
        ModProductAddPartSearchField.setText("");
    }

    void ClearSearchRemove(ActionEvent event) {
      updateDelPartTable();
        ModProductDeletePartSearchField.setText("");
    }

    @FXML
    void ModifyProductsSearchPartAddBtn (ActionEvent event) {
        String searchPart = ModProductAddPartSearchField.getText();//ModProductAddPartSearchField;
                
        //if partSearch is empty, update part table with all parts
        
          boolean found=false;
        if (!ModProductAddPartSearchField.getText().trim().isEmpty()){
            try{
                  int search = Integer.parseInt(ModProductAddPartSearchField.getText());
        for (Part p: Inventory.allParts){
            if (p.getId() == search){
                MPAT.getSelectionModel().select(p);
             found=true;
            }
        }if (found==false){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
            alert.setHeaderText("Error finding Product ");
            alert.setContentText("Please type a ProductID/ProductName from the list");
            alert.showAndWait();
             MPAT.getSelectionModel().clearSelection();
           }}
             catch(NumberFormatException e){
                     String search = (ModProductAddPartSearchField.getText());
        for (Part p: Inventory.allParts){
            if (p.getName().equals(search) ){
                MPAT.getSelectionModel().select(p); 
              found=true;
            }} if (found==false){Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No Parts Found");
            alert.setContentText("Please Try Again with a part from the list");
            alert.showAndWait();
            MPAT.getSelectionModel().clearSelection();
             }}
           
                     }     

        
        
            
    
    }
        
    @FXML
    void ModifyProductsAddButton(ActionEvent event) {
        Part part = MPAT.getSelectionModel().getSelectedItem();
        //.addAssociatedPart(part);
        if(part!= null){
        TemporaryProduct.getAllAssociatedParts().add(part);
       
 ModProductDeleteTable.setItems(TemporaryProduct.getAllAssociatedParts());
       //updateDelPartTable();
        }
       
    }

    void ModifyProductsSearchPartDeleteBtn(ActionEvent event) {
     // TextField searchPart = ModProductAddPartSearchField;
        TextField delsearchPart = ModProductDeletePartSearchField;
       if (!delsearchPart.getText().trim().isEmpty()){
            try{
                  int searched = Integer.parseInt(delsearchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getId() == searched){
                ModProductDeleteTable.getSelectionModel().select(p);
            }
        }}
             catch(NumberFormatException e){
                     String search = (delsearchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getName().equals(search) ){
                ModProductDeleteTable.getSelectionModel().select(p); 
            }
                     }     

        }
        
            
    }
    }

       
    
//Remove Product Button- Grab code from Delete Button
    @FXML
    void ModifyProductsDeleteButton(ActionEvent event) {
         Part part = ModProductDeleteTable.getSelectionModel().getSelectedItem();
        

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirm Current Part Delete!");
        alert.setContentText("Are you sure you want to delete part ");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            System.out.println("Part delete button clicked.");
            TemporaryProduct.deleteAssociatedPart(part);
           //return remove;
        } else {
            System.out.println("Cancel clicked.");
        }
        //return false;
   
            }

    @FXML
    void ModifyProductsSaveButtonClicked(ActionEvent event) throws IOException {
     try{   
        
         int id = Inventory.getproductGen();
     String name=ModProductsNameField.getText();
    double price=Double.parseDouble(ModProductsPriceField.getText());
     int stock=Integer.parseInt(ModProductsInvField.getText());
     int min=Integer.parseInt(ModProductsMinField.getText());
     int max=Integer.parseInt(ModProductsMaxField.getText());
        
        
        
        String productName = ModProductsNameField.getText();
        String productInv = ModProductsInvField.getText();
        String productPrice = ModProductsPriceField.getText();
        String productMin = ModProductsMinField.getText();
        String productMax = ModProductsMaxField.getText();
        bottomTableParts.addAll(ModProductDeleteTable.getItems());
       // TemporaryProduct  .deleteAssociatedPart(part);
        if (exceptionMessage.length() > 0) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error Adding Product");
            alert.setHeaderText("Error");
            alert.setContentText(exceptionMessage);
            alert.showAndWait();
            exceptionMessage = "";
        } else{
                Product newProduct = new Product();
                newProduct.setId(productID);
                newProduct.setName(productName);
                newProduct.setPrice(Double.parseDouble(productPrice));
                newProduct.setStock(Integer.parseInt(productInv));
                newProduct.setMin(Integer.parseInt(productMin));
                newProduct.setMax(Integer.parseInt(productMax));
               newProduct.setAssociatedPart(bottomTableParts);
               //TemporaryProduct.deleteAssociatedPart(part);
                Inventory.updateProduct(productIndex, newProduct);

                Parent productsSave = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
                Scene scene = new Scene(productsSave);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene);
                window.show();
        }
        if (min > max) {
              
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
             
            }
            if (stock < min) {
             
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with smaller than minimum, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;   
                    }
            if (stock > max) {
               
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue withstock being larger than max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return; 
               
            }
            /**
             ** @Challenges I had multiple exceptions, but creating this one allowed me to do more, with less, so to speak. Big logic errors with the rest of the included exceptions
             ** @Updates: Should work fine with Java SE
             */
     }catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error Modifying Product");
            alert.setContentText("Form contains incorrectly added fields. Stock, Price, Min, and Max Should be numbers");
            alert.showAndWait();
            
        }
    }
    
   @FXML
    void ModifyProductsCancelClicked(ActionEvent event) throws IOException {
       
 Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave?");
        Optional<ButtonType> result = alert.showAndWait();

        
        if (result.get() == ButtonType.OK) {

            Parent partsCancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(partsCancel);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } else {
            System.out.println("You clicked cancel. Please complete part info.");
        }
        
        
        
        
        } 
 /**
     * Initializes the controller class.
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Product product = GetAllProducts().get(productIndex);
        productID = GetAllProducts().get(productIndex).getId();
        System.out.println("Product ID " + productID + " is available.");
        ModProductsIDField.setText("AUTO GEN: " + productID);
        ModProductsNameField.setText(product.getName());
        ModProductsInvField.setText(Integer.toString(product.getStock()));
        ModProductsPriceField.setText(Double.toString(product.getPrice()));
        ModProductsMinField.setText(Integer.toString(product.getMin()));
        ModProductsMaxField.setText(Integer.toString(product.getMax()));
       // associatedParts = product.getAllAssociatedParts();
        
        
        
        ModProductPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModProductPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        ModProductPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModProductPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        MPAT.setItems(Inventory.GetAllParts());
        
        // Ask "How do I get this piece to transfer when I  add
      ModProductDeleteTable.setItems(bottomTableParts);
        ModProductDelPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModProductDelPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
       ModProductDelPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModProductDelPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
       // updatePartTable();
        // updateDelPartTable();
    }        /**
     *   updatePartTable was created to get around the logical error of not having a way to update the table once I'd added to it detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
 public void updatePartTable() {
        MPAT.setItems(GetAllParts());
    }
/**
     *  updateDelPartTable was created to power the remove Associated Part Button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public void updateDelPartTable() {
        ModProductDeleteTable.setItems(bottomTableParts);
    }

   
}

    
 
    

   

   

   
    
    

