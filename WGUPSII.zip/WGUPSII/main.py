import HashMap
import csv


PackageID = []
Address = []
h = HashMap.HashMap()
with open('WGUPS Package File.csv', 'r', encoding='utf8') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    for row in readCSV:
        PackageID = []
        Address = []
        package = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]]
        h.add(row[0], package)
        PackageID.append(row[0])
        Address.append(package)

# Holistic Loading, Packages

Ride1 = [1, 13, 14, 15, 16, 17, 19, 30, 31, 34, 37, 40]
Ride2 = [3, 6, 18, 25, 36, 38, 32, 33, 35, 39]
Ride3 = [2, 4, 5, 7, 8, 9, 10, 11, 21, 22, 23, 24, 26, 27, 28]

GPSMatrix = []
# Read in csv file that is the mapping of distances between locations
with open('WGUPS Distance Numbers.csv') as csvfile:
    readCSV2 = csv.reader(csvfile, delimiter=',')
    readCSV2 = list(readCSV2)
    for row in readCSV2:
        GPS = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11],
               row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20], row[21], row[22],
               row[23], row[24], row[25], row[26]]
        GPSMatrix.append(row)
print("GPS Numbers")
print(GPSMatrix)

# Read in csv file that is the names of all possible delivery locations
Rolodex = []
RolodexAddressOnly = []
with open('WGUPS Distance Names.csv') as csv_name_file:
    readCSV3 = csv.reader(csv_name_file, delimiter=',')
    readCSV3 = list(readCSV3)
    for row in readCSV3:
        Book = [row[0], row[1], row[2]]

        Rolodex.append(row)
        RolodexAddressOnly.append(row[2])
print("GPS NAMES")
print(Rolodex)
print(RolodexAddressOnly)

# Print GPS Matrix
for row in GPSMatrix:
    print(row)
for i in range(27):
    for j in range(27):
        print(GPSMatrix[i][j])

# When Do the Trucks leave the hub, time stored in hours

FirstLeave = ['8']
SecondLeave = ['9.1']
ThirdLeave = ['10.35']


# '4001 South 700 East', '1060 Dalton Ave S',
def getDistance(fromAddress, toAddress):
    return float(GPSMatrix[RolodexAddressOnly.index(toAddress)][RolodexAddressOnly.index(fromAddress)])


print("Get Distance Results")
print(getDistance('4001 South 700 East', '1060 Dalton Ave S'))

# CurrentTruckAddress- where the truck is variable


# Lookup Function



txt = input("Hi, welcome to the WGUPS, How may I help you? Press '0' to get all packages displayed, "
            "or type the key to get a specific package ")

if txt == '0':
    h.print()
    # elif txt is "All": print(lookupStatusDict[txt])else:
    search = input("type the number of the package to get that one specifically ")
    print(h.get(search))
if txt != '0':
    print(h.get(txt))
