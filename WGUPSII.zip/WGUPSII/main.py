import HashMap
import csv

import Packages
import delivery_truck

PackageID = []
Address = []
h = HashMap.HashMap()
with open('WGUPS Package File.csv', 'r', encoding='utf8') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    for row in readCSV:
        PackageID = []
        Address = []
        package = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]]
        h.add(row[0], package)
        PackageID.append(row[0])
        Address.append(package)

# Holistic Loading, Packages

Ride1 = [1, 13, 14, 15, 16, 17, 19, 30, 31, 34, 37, 40]
Ride2 = [3, 6, 18, 25, 36, 38, 32, 33, 35, 39]
Ride3 = [2, 4, 5, 7, 8, 9, 10, 11, 21, 22, 23, 24, 26, 27, 28]

Ride1O = [1, 14, 13, 15, 16, 17, 19, 30, 31, 34, 37, 40]

Ride2O = [3, 6, 18, 25, 36, 38, 32, 33, 35, 39]

Ride3O = [2, 4, 5, 7, 8, 9, 10, 11, 21, 22, 23, 24, 26, 27, 28]

# When Do the Trucks leave the hub, time stored in hours

FirstLeave = ['8']
SecondLeave = ['9.1']
ThirdLeave = ['10.35']

# CurrentTruckAddress- where the truck is variable


# Lookup Function


txt = input("Hi, welcome to the WGUPS, How may I help you? Press '0' to get all packages displayed, "
            "or type the key to get a specific package ")

if txt == '0':
    h.print()
    # elif txt is "All": print(lookupStatusDict[txt])else:
    search = input("type the number of the package to get that one specifically ")
    print(h.get(search))
if txt != '0':
    print(h.get(txt))
h = HashMap.HashMap()

h = Packages.HashMaker(h)

AmazonTruck = delivery_truck.Truck()
AmazonTruck.greedy(8, Ride1O, h)
