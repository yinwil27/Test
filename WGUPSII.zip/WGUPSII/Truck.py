import Packages
import HashMap
import main


class Truck:
    CurrentTime = 0  # Current time, in hours
    LeaveTime = 0  # Time you left, in hours,
    TravelTime = 0  # Time it takes for you to travel with this package
    newdistance = 0
    listOfDeliveredItems = []
    # CurrentMilesTraveled = []
    newMiles = 0  # Miles traveled so far, miles traveled on CURRENT truck

    def __init__(self):
        self.package_list = []
        self.size = 6
        self.Location = '4001 South 700 East'
        self.LeaveTime = 0  # in hours,
        self.CurrentTime = 0  # in hours
        self.totalMiles = 0

    # Package ID

    # Three upper functions, in order, currentTravel, odometer, stopwatch

    def deliver(self, packageID, h):
        package_list = h.get(packageID)
        addy = package_list[1]
        Truck.listOfDeliveredItems.append(addy)
        newdistance = main.getDistance(self.Location, addy)
        stopwatch = newdistance / 18.0
        newdistance = newdistance + self.totalMiles
        status = 3
        package_list[8] = status
        clock = self.CurrentTime + stopwatch
        package_list[9] = str(clock)
        # need to add newMiles to odometer

        return print("Truck Delivery: package: " + package_list[0] + "  is now delivered. It was delivered at: " +
                     addy + ", with a total distance of " +
                     str(newdistance) + ' miles and took ' + str(stopwatch) + ' hours')

    def greedy(self, timetostart, Ride):

        minDistance = 1000  # highest number not in list
        minIndex = 200
        b = main.RolodexAddressOnly[0]  # b = the current address of the truck
        self.CurrentTime = timetostart
        PossibleAddresses = []

        while len(Ride) > 0:
            for n in Ride:
                # Is Hub
                PossiblePackage = h.get(str(n))
                g = main.getDistance(b, PossiblePackage[1])

                if g < minDistance:

                    minDistance = g
                    minIndex = str(Ride.index(n))
                    Truck.deliver(minIndex, h)
                    Ride.pop(n)

                # make a new list of the same ride, instead.when you get here deliver package and pop from that list,
                # loop through until that list is empty.

        print('Greedy Test: ' + str(minDistance), minIndex)


h = HashMap.HashMap()

h = Packages.HashMaker(h)
truckAmazon = Truck()
Ride1O = [1, 14, 13, 15, 16, 17, 19, 30, 31, 34, 37, 40]

Ride2O = [3, 6, 18, 25, 36, 38, 32, 33, 35, 39]

Ride3O = [2, 4, 5, 7, 8, 9, 10, 11, 21, 22, 23, 24, 26, 27, 28]
'''print(greedy(minDistance1, Dictionary.Trip1Dict))'''
truckAmazon.greedy(str(8), Ride1O)
# truckAmazon.deliver('5', h)
