import Distance
import Packages
import HashMap


class Truck:
    CurrentTime = 0  # Current time, in hours
    LeaveTime = 0  # Time you left, in hours,
    TravelTime = 0  # Time it takes for you to travel with this package
    newdistance = 0
    listOfDeliveredItems = []
    # CurrentMilesTraveled = []
    miles = 0  # Miles traveled so far

    def __init__(self):
        self.package_list = []
        self.size = 6
        self.Location = '4001 South 700 East'
        self.LeaveTime = 0  # in hours,
        self.CurrentTime = 0  # in hours
        self.totalMiles = 0

    def odometer(self, totalMiles):
        odometerVariable = Truck.miles + totalMiles

    def currentTravel(miles):
        Truck.travel + Truck.newdistance

    def stopwatch(LeaveTime):
        LeaveTime + Truck.CurrentTime

    # Package ID

    def howLongDoesItTakeToDeliver(mph):
        return print(str(float(newdistance) / mph) + 'hours to deliver')

    def deliver(self, packageID, h):
        package_list = h.get(packageID)
        addy = package_list[1]
        Truck.listOfDeliveredItems.append(addy)
        newdistance = Distance.getDistance(self.Location, addy)

        return print("package: " + package_list[0] + " was delivered at " + addy + " Distance of " + newdistance +
                     " it takes " + str(float(newdistance) / 18.0) + " hours.")


h = HashMap.HashMap()

h = Packages.HashMaker(h)
truckAmazon = Truck()
print(str(Truck.stopwatch(8.5)))
'''print(greedy(minDistance1, Dictionary.Trip1Dict))'''
truckAmazon.deliver('5', h)
truckAmazon.odometer(truckAmazon.howLongDoesItTakeToDeliver(18))
