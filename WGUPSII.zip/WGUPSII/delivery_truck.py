
import csv

GPSMatrix = []
# Read in csv file that is the mapping of distances between locations
with open('WGUPS Distance Numbers.csv') as csvfile:
    readCSV2 = csv.reader(csvfile, delimiter=',')
    readCSV2 = list(readCSV2)
    for row in readCSV2:
        GPS = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11],
               row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20], row[21], row[22],
               row[23], row[24], row[25], row[26]]
        GPSMatrix.append(row)
print("GPS Numbers")
print(GPSMatrix)

# Read in csv file that is the names of all possible delivery locations
Rolodex = []
RolodexAddressOnly = []
with open('WGUPS Distance Names.csv') as csv_name_file:
    readCSV3 = csv.reader(csv_name_file, delimiter=',')
    readCSV3 = list(readCSV3)
    for row in readCSV3:
        Book = [row[0], row[1], row[2]]

        Rolodex.append(row)
        RolodexAddressOnly.append(row[2])
print("GPS NAMES")
print(Rolodex)
print(RolodexAddressOnly)

# Print GPS Matrix
for row in GPSMatrix:
    print(row)
for i in range(27):
    for j in range(27):
        print(GPSMatrix[i][j])


# '4001 South 700 East', '1060 Dalton Ave S',
def getDistance(fromAddress, toAddress):
    return float(GPSMatrix[RolodexAddressOnly.index(toAddress)][RolodexAddressOnly.index(fromAddress)])

# Test the getDistance function
print("Get Distance Results")
print(getDistance('4001 South 700 East', '1060 Dalton Ave S'))


class Truck:
    CurrentTime = 0  # Current time, in hours
    LeaveTime = 0  # Time you left, in hours,
    TravelTime = 0  # Time it takes for you to travel with this package
    newdistance = 0
    listOfDeliveredItems = []
    # CurrentMilesTraveled = []
    newMiles = 0  # Miles traveled so far, miles traveled on CURRENT truck

    def __init__(self):
        self.package_list = []
        self.size = 6
        self.Location = '4001 South 700 East'
        self.LeaveTime = 0  # in hours,
        self.CurrentTime = 0  # in hours
        self.totalMiles = 0
        # self.MinPID = 0

    # Package ID

    # Three upper functions, in order, currentTravel, odometer, stopwatch

    def greedy(self, timetostart, Ride, h):

        minDistance = 1000  # highest number not in list
        minPID = 200
        b = RolodexAddressOnly[0]  # b = the current address of the truck
        self.CurrentTime = timetostart

        # while len(Ride) > 0:
        for n in Ride:
            # Is Hub
            PossiblePackage = h.get(str(n))
            status = "In Transit"  # Change the status to 2 'in transit'
            PossiblePackage[8] = status
            g = getDistance(b, PossiblePackage[1])

            if g < minDistance:
                minDistance = g
                minIndex = str(Ride.index(n))  # Change min index to min package id
                minPID = str(n)

        self.deliver(minPID, h)

        # Ride.remove(n)
        # make a new list of the same ride, instead.when you get here deliver package and pop from that list,
        # loop through until that list is empty.

    def deliver(self, packageID, h):
        package_list = h.get(packageID)
        addy = package_list[1]
        Truck.listOfDeliveredItems.append(addy)
        newdistance = getDistance(self.Location, addy)
        stopwatch = newdistance / 18.0
        newdistance = newdistance + self.totalMiles

        package_list[8] = "delivered"
        clock = self.CurrentTime + stopwatch
        package_list[9] = (str(clock) + " Hours")
        # need to add newMiles to odometer

        return print("Truck Delivery: package: " + package_list[0] + "  is now delivered. It was delivered at: " +
                     addy + ", with a total distance of " +
                     str(newdistance) + ' miles and took ' + str(stopwatch) + ' hours')


