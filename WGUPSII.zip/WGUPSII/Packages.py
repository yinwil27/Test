import csv

import HashMap

PackageID = []
Address = []
h = HashMap.HashMap()
with open('WGUPS Package File.csv', 'r', encoding='utf8') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    for row in readCSV:
        PackageID = []
        Address = []
        package = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]]
        h.add(row[0], package)
        PackageID.append(row[0])
        Address.append(package)


def HashMaker(h):
    with open('WGUPS Package File.csv', 'r', encoding='utf8') as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        for row in readCSV:
            PackageID = []
            Address = []
            package = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]]
            h.add(row[0], package)
            PackageID.append(row[0])
            Address.append(package)
    return h

# Holistically Sort Packages, Loaded manually onto trucks


Ride1 = [1, 13, 14, 15, 16, 17, 19, 30, 31, 34, 37, 40]
Ride2 = [3, 6, 18, 25, 36, 38, 32, 33, 35, 39]
Ride3 = [2, 4, 5, 7, 8, 9, 10, 11, 21, 22, 23, 24, 26, 27, 28]
