'''4. Create a Distance.py class that has methods to calculate distance,
travel time, etc. . In this class, parse the CSV file that has the locations.
Then youre going to create a matrix (2 dimensional array). array[startinglocation, endinglocation]
= 3.5 (miles). That way when youre executing the route, you can do a loop that just looks at the
current location and the next location and you can call your Distance.calculateLocation(index 1, index 2)
to get a distance. And with that distance obviously you can get a time.'''


import csv

import HashMap

GPSMatrix = []
# Read in csv file that is the mapping of distances between locations
with open('WGUPS Distance Numbers.csv') as csvfile:
    readCSV2 = csv.reader(csvfile, delimiter=',')
    readCSV2 = list(readCSV2)
    for row in readCSV2:
        GPS = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11],
               row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20], row[21], row[22],
               row[23], row[24], row[25], row[26]]
        GPSMatrix.append(row)
print("GPS Numbers")
print(GPSMatrix)


# Read in csv file that is the names of all possible delivery locations
Rolodex = []
RolodexAddressOnly = []
with open('WGUPS Distance Names.csv') as csv_name_file:
    readCSV3 = csv.reader(csv_name_file, delimiter=',')
    readCSV3 = list(readCSV3)
    for row in readCSV3:
        Book = [row[0], row[1], row[2]]

        Rolodex.append(row)
        RolodexAddressOnly.append(row[2])
print("GPS NAMES")
print(Rolodex)
print(RolodexAddressOnly)

# 2 dimensional getDistance Array


# Print GPS Matrix
for row in GPSMatrix:
    print(row)
for i in range(27):
    for j in range(27):
        print(GPSMatrix[i][j])


# '4001 South 700 East', '1060 Dalton Ave S',
def getDistance(fromAddress, toAddress):
    return GPSMatrix[RolodexAddressOnly.index(toAddress)][RolodexAddressOnly.index(fromAddress)]


print("Get Distance Results")
print(getDistance('4001 South 700 East', '1060 Dalton Ave S'))













