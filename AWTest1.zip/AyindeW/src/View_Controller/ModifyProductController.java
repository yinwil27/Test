/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package View_Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.Inventory;
import static Model.Inventory.GetAllParts;
import static Model.Inventory.GetAllProducts;
import Model.Part;
import Model.Product;
import static View_Controller.MainScreenController.productToModifyIndex;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;



/**
 * FXML Controller class
 *
 * @author Ayinde
 */

public class ModifyProductController implements Initializable {

    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    Product NewGuy = new Product(5,"",0.0,0,0,0);
    private int productIndex = productToModifyIndex();
    private String exceptionMessage = new String();
    private int productID;

    @FXML
    private TextField ModProductsIDField;
    @FXML
    private TextField ModProductsMinField;
    @FXML
    private TextField ModProductsMaxField;
    @FXML
    private TextField ModProductsInvField;
    @FXML
    private TextField ModProductsNameField;
    @FXML
    private TextField ModProductsPriceField;
    @FXML
    private TextField ModProductAddPartSearchField;
    @FXML
    private TextField ModProductDeletePartSearchField;
    @FXML
    private TableView<Part> MPAT;
    @FXML
    private TableColumn<Part, Integer> ModProductPartIDCol;
    @FXML
    private TableColumn<Part, String> ModProductPartNameCol;
    @FXML
    private TableColumn<Part, Integer> ModProductPartInvCol;
    @FXML
    private TableColumn<Part, Double> ModProductPartPriceCol;
    @FXML
    private TableView<Part> ModProductDeleteTable;
    @FXML
    private TableColumn<Part, Integer> ModProductDelPartIDCol;
    @FXML
    private TableColumn<Part, String> ModProductDelPartNameCol;
    @FXML
    private TableColumn<Part, Integer> ModProductDelPartInvCol;
    @FXML
    private TableColumn<Part, Double> ModProductDelPartPriceCol;
    @FXML
    private Button ModProdCancel;
    @FXML
    private Button ModProdSaved;
    @FXML
    private Button RemoveButton;
    
    

    
    public void toughWork(Product Dyn){
       
        productID = GetAllProducts().get(productIndex).getId();
        ModProductsIDField.setText("Part ID autoset to: " + Dyn.getId());
        ModProductsNameField.setText(Dyn.getName());
        ModProductsInvField.setText(Integer.toString(Dyn.getStock()));
        ModProductsPriceField.setText(Double.toString(Dyn.getPrice()));
        ModProductsMinField.setText(Integer.toString(Dyn.getMin()));
        ModProductsMaxField.setText(Integer.toString(Dyn.getMax()));
        ModProductDeleteTable.setItems(associatedParts);  
      
    }
    public void slim (Product Dyn){
        //MPAT.setItems(Inventory.GetAllParts());
     
    }
 
    void ClearSearchAdd(ActionEvent event) {
      updatePartTable();
        ModProductAddPartSearchField.setText("");
    }

    void ClearSearchRemove(ActionEvent event) {
      updateDelPartTable();
        ModProductDeletePartSearchField.setText("");
    }

    @FXML
    void ModifyProductsSearchPartAddBtn(ActionEvent event) {
        TextField searchPart = ModProductAddPartSearchField;//ModProductAddPartSearchField;
                
        //if partSearch is empty, update part table with all parts
        if (!searchPart.getText().trim().isEmpty()){
            try{
                  int search = Integer.parseInt(searchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getId() == search){
                MPAT.getSelectionModel().select(p);
            }
        }}
             catch(NumberFormatException e){
                     String search = (searchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getName().equals(search) ){
                MPAT.getSelectionModel().select(p); 
            }
                     }     

        }
        
            
    }}
    @FXML
    void ModifyProductsAddButton(ActionEvent event) {
        Part part = MPAT.getSelectionModel().getSelectedItem();
        associatedParts.add(part);
       updateDelPartTable();
    }

    @FXML
    void ModifyProductsSearchPartDeleteBtn(ActionEvent event) {
     // TextField searchPart = ModProductAddPartSearchField;
        TextField delsearchPart = ModProductDeletePartSearchField;
       if (!delsearchPart.getText().trim().isEmpty()){
            try{
                  int searched = Integer.parseInt(delsearchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getId() == searched){
                MPAT.getSelectionModel().select(p);
            }
        }}
             catch(NumberFormatException e){
                     String search = (delsearchPart.getText());
        for (Part p: Inventory.allParts){
            if (p.getName().equals(search) ){
                MPAT.getSelectionModel().select(p); 
            }
                     }     

        }
        
            
    }
    }

       
    
//Remove Product Button- Grab code from Delete Button
    @FXML
    void ModifyProductsDeleteButton(ActionEvent event) {
        Part Prpart = ModProductDeleteTable.getSelectionModel().getSelectedItem();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirm Part Delete");
        alert.setContentText("Are you sure you want to get rid of " + Prpart.getName() + " ?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            
            NewGuy.associatedParts.remove(Prpart);
        } else {
            System.out.println("Cancel was clicked.");
        }
    }

    @FXML
    void ModifyProductsSaveButtonClicked(ActionEvent event) throws IOException {
     try{   
        
         int id = Inventory.partGen;
     String name=ModProductsNameField.getText();
    double price=Double.parseDouble(ModProductsPriceField.getText());
     int stock=Integer.parseInt(ModProductsInvField.getText());
     int min=Integer.parseInt(ModProductsMinField.getText());
     int max=Integer.parseInt(ModProductsMaxField.getText());
        
        
        
        String productName = ModProductsNameField.getText();
        String productInv = ModProductsInvField.getText();
        String productPrice = ModProductsPriceField.getText();
        String productMin = ModProductsMinField.getText();
        String productMax = ModProductsMaxField.getText();
        if (exceptionMessage.length() > 0) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error Adding Product");
            alert.setHeaderText("Error");
            alert.setContentText(exceptionMessage);
            alert.showAndWait();
            exceptionMessage = "";
        } else{
                Product newProduct = new Product(8,"", 0.0, 0, 0,00);
                newProduct.setId(productID);
                newProduct.setName(productName);
                newProduct.setPrice(Double.parseDouble(productPrice));
                newProduct.setStock(Integer.parseInt(productInv));
                newProduct.setMin(Integer.parseInt(productMin));
                newProduct.setMax(Integer.parseInt(productMax));
               // newProduct.setAssociatedParts(associatedParts);
                Inventory.updateProduct(productIndex, newProduct);

                Parent productsSave = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
                Scene scene = new Scene(productsSave);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene);
                window.show();
        }
        if (min > max) {
              
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
             
            }
            if (stock < min) {
             
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with smaller than minimum, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;   
                    }
            if (stock > max) {
               
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue withstock being larger than max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return; 
               
            }
     }catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error Modifying Product");
            alert.setContentText("Form contains incorrectly added fields. Stock, Price, Min, and Max Should be numbers");
            alert.showAndWait();
        }
    }
    
   @FXML
    void ModifyProductsCancelClicked(ActionEvent event) throws IOException {
       

        
            Parent partsCancel = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
            Scene scene = new Scene(partsCancel);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } 
 /**
     * Initializes the controller class.
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Product product = GetAllProducts().get(productIndex);
        productID = GetAllProducts().get(productIndex).getId();
        System.out.println("Product ID " + productID + " is available.");
        ModProductsIDField.setText("AUTO GEN: " + productID);
        ModProductsNameField.setText(product.getName());
        ModProductsInvField.setText(Integer.toString(product.getStock()));
        ModProductsPriceField.setText(Double.toString(product.getPrice()));
        ModProductsMinField.setText(Integer.toString(product.getMin()));
        ModProductsMaxField.setText(Integer.toString(product.getMax()));
        associatedParts = product.getAllAssociatedParts();
        
        
        
        ModProductPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModProductPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        ModProductPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModProductPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        MPAT.setItems(Inventory.GetAllParts());
        
        // Ask "How do I get this piece to transfer when I  add
       ModProductDeleteTable.setItems( associatedParts);
        ModProductDelPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        ModProductDelPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
       ModProductDelPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ModProductDelPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }        
 public void updatePartTable() {
        MPAT.setItems(GetAllParts());
    }

    public void updateDelPartTable() {
        ModProductDeleteTable.setItems(associatedParts);}

   
}

    
 
    

   

   

   
    
    

