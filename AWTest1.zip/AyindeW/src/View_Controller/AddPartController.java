/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import Model.InhousePart;
import Model.OutsourcedPart;
import Model.Inventory;
import Model.Part;

/**
 * FXML Controller class
 *
 * @author Ayinde
 */
public class AddPartController implements Initializable {

    @FXML
    private RadioButton inHouse;
    @FXML
    private RadioButton outSourced;

    @FXML
    private TextField machineIDfield;
    @FXML
    private Text machineIDlabel;
    @FXML
    private Button Save;
    @FXML
    private Button Cancel;

    @FXML
    private Pane PartsPane;
    @FXML
    private ToggleGroup TogglesAdd;
    @FXML
    private TextField AddPartName;
    @FXML
    private TextField AddPartPC;
    @FXML
    private TextField AddPartMax;
    @FXML
    private TextField AddPartInv;
    @FXML
    private TextField AddPartMin;
private String exception; 
    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
     Inventory.partGen += 1;  
    }

    /**
     *
     * @param event
     * @throws IOException
     */
    @FXML
    public void Save(ActionEvent event) throws IOException {
        try{
   int id = Inventory.partGen;
     String name=AddPartName.getText();
    double price=Double.parseDouble(AddPartPC.getText());
     int stock=Integer.parseInt(AddPartInv.getText());
     int min=Integer.parseInt(AddPartMin.getText());
     int max=Integer.parseInt(AddPartMax.getText());
     
     
      if (TogglesAdd.getSelectedToggle().equals(inHouse)) {
            Part iHpart2 = new InhousePart(3, "", 0.0, 0, 0, 00, 0000);
            
           
           
            
            if (!AddPartName.getText().isEmpty()) {
                //repeat 5 times 
                iHpart2.setName(AddPartName.getText());
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Name is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!AddPartInv.getText().isEmpty()) {
                //repeat 4 times 
                iHpart2.setStock(Integer.parseInt(AddPartInv.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Inv is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!AddPartPC.getText().isEmpty()) {
                //repeat 3 times 
                iHpart2.setPrice(Double.parseDouble(AddPartPC.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Price is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!AddPartMax.getText().isEmpty()) {
                //repeat 2 times 
                iHpart2.setMax(Integer.parseInt(AddPartMax.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Max is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (!AddPartMin.getText().isEmpty()) {
                //repeat 1 times 
                iHpart2.setMin(Integer.parseInt(AddPartMin.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Min is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
           if (!machineIDfield.getText().isEmpty()) {
                //done 
                ((InhousePart) iHpart2).setMachineId(Integer.parseInt(machineIDfield.getText()));
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Field is Missing/Incorrect");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
           
         
           
            if (min > max) {
              
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                  
            }
            if (stock < min) {
                
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is smaller than mimimum, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
               
            }
            if (stock > max) {
                
 Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with stock being larger than max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
                    }
            
            
            Inventory.AddPart(iHpart2);
            Parent Cancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(Cancel);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
            
        }        
           
        if (TogglesAdd.getSelectedToggle().equals(outSourced)) {
            Part oSpart2 = new OutsourcedPart(4, "", 0.0, 0, 0, 00, "312");
            if (!AddPartName.getText().isEmpty()) {
                //repeat 5 times 
                oSpart2.setName(AddPartName.getText());
            }
            if (!AddPartInv.getText().isEmpty()) {
                //repeat 4 times 
                oSpart2.setStock(Integer.parseInt(AddPartInv.getText()));
            }
            if (!AddPartPC.getText().isEmpty()) {
                //repeat 3 times 
                oSpart2.setPrice(Double.parseDouble(AddPartPC.getText()));
            }
            if (!AddPartMax.getText().isEmpty()) {
                //repeat 2 times 
                oSpart2.setMax(Integer.parseInt(AddPartMax.getText()));
            }
            if (!AddPartMin.getText().isEmpty()) {
                //repeat 1 times 
                oSpart2.setMin(Integer.parseInt(AddPartMin.getText()));
            }
            if (!machineIDfield.getText().isEmpty()) {
                //done 
                ((OutsourcedPart) oSpart2).setCompanyName((machineIDfield.getText()));
            }
            
            if (min > max) {
              
                 
                  Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with Min/Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (stock < min) {
                Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Stock is smaller than minimum, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }
            if (stock > max) {
            Alert alert = new Alert(Alert.AlertType.ERROR);

                alert.setTitle("Confirmation");
                alert.setHeaderText("You Sure?!");
                alert.setContentText("Issue with stock being larger than Max, please modify");
                Optional<ButtonType> result = alert.showAndWait();
                return;    
                
            }
            Inventory.AddPart(oSpart2);
             
            Parent Cancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(Cancel);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
           
        }
     
     Inventory.partGen+=1;
    }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Error Modifying Product");
            alert.setContentText("Form contains incorrectly added fields. Stock, Price, Min, and Max Should be numbers");
            alert.showAndWait();
        }
    }
    public RadioButton getoutSourced() {
        return outSourced;
    }

    @FXML
    private void OnInhouse(ActionEvent event) {
        machineIDlabel.setText("Machine ID");
    }

    @FXML
    private void onOutsourced(ActionEvent event) {
        machineIDlabel.setText("Company Name");
    }

    @FXML
    public void Cancel(ActionEvent event) throws IOException {
        
        
        
        
         Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initModality(Modality.NONE);
        alert.setTitle("Double Check");
        alert.setHeaderText("Go Back?");
        alert.setContentText("you want to leave ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {

            Parent Cancel = FXMLLoader.load(getClass().getResource("/View_Controller/MainScreen.fxml"));
            Scene scene = new Scene(Cancel);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(scene);
            window.show();
        } else {
            System.out.println("You clicked cancel. Please complete part info.");
        }
        

    }
}
