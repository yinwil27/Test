/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Ayinde
 */
public class Inventory {
   public static int partGen;
   public static int productGen;
   
    public static ObservableList<Part> allParts = FXCollections.observableArrayList();
    public static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static ObservableList<Part> lookupPart = FXCollections.observableArrayList();
     private static ObservableList<Product> lookupProduct = FXCollections.observableArrayList();
    public static void AddPart(Part Newpart) {
        allParts.add(Newpart);
    }

    public static void AddProduct(Product NewProduct) {
        allProducts.add(NewProduct);
    }

    public static Part lookupPart(int partPiece) {
      if (!allParts.isEmpty()) {
            for (int i = 0; i < allParts.size(); i++) {
                if (allParts.get(i).getId() == partPiece) {
                    return allParts.get(i);
                }
            }

        }
        return null;
    }


//{

      //  for (Part cm : allParts) {
        //    if (cm.getId() == (partPiece)) {                     

          //      return cm;
            //}
            
       // }
       // return null;
    //}
    
    
    
    
    
    
    
    
    
        /**
         *
         * @param partName
         * @return
         */
    public static final ObservableList<Part> lookupPart (String partName) {
         ObservableList<Part> eo = FXCollections.observableArrayList();
           

        for (Part dn : allParts)
           {
        if (partName.compareTo(dn.getName())==0)
                { eo.add(dn);
                     }
        }   
        return eo;
    }
    
    



public static Product lookupProduct(int productid) {
        for(Product cm: allProducts) {
           if(cm.getId() == productid){
               
           return cm;}
        }return null;}

/**
         *
         * @param productName
         * @return
         */

 public static ObservableList<Product> lookupProduct(String productName) {
        return allProducts.sorted();   
}
 
public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }

public static void updateProduct(int index, Product selectedProduct) {
        allProducts.set(index, selectedProduct);
    }
public static boolean deletePart(Part selectedPart){
        return allParts.remove(selectedPart);
}
public static boolean deleteProduct(Product selectedProduct){
        return allProducts.remove(selectedProduct);
}

public static ObservableList<Product> GetAllProducts(){
           return allProducts;
               }

    public static ObservableList<Part> GetAllParts() {
        return allParts; //To change body of generated methods, choose Tools | Templates.
    }
}







    /**/
