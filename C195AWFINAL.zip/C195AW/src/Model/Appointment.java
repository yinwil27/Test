/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 *
 * @author Wakiti
 */
public class Appointment {

    private int Appointment_ID;
    private int userid;
    private String UserName;
    private int customerid;
    private String customerName;
    private int contactid;
    private String contactName;
    private String Title;
    private String description;
    private String location;

    private String type;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;

    public Appointment(int Appointment_ID, int userid, String UserName, int customerid, String customerName, int contactid, String contactName, String Title, String description, String location, String type, LocalDate date, LocalTime startTime, LocalTime endTime) {
        this.Appointment_ID = Appointment_ID;
        this.userid = userid;
        this.UserName = UserName;
        this.customerid = customerid;
        this.customerName = customerName;
        this.contactid = contactid;
        this.contactName = contactName;
        this.Title = Title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int getAppointment_ID() {
        return Appointment_ID;
    }

    public int getUserid() {
        return userid;
    }

    public String getUserName() {
        return UserName;
    }

    public int getCustomerid() {
        return customerid;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getContactid() {
        return contactid;
    }

    public String getContactName() {
        return contactName;
    }

    public String getTitle() {
        return Title;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public String getType() {
        return type;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }
    

  
}
