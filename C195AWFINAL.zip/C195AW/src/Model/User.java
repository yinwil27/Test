/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Wakiti
 */
public class User {
    int userid;
    String UserName;
    String PassWord;
  public User(int userid, String UserName) {
        this.userid = userid;
        this.UserName = UserName;
    }

    public int getUserid() {
        return userid;
    }

    public String getUserName() {
        return UserName;
    }

    public String getPassWord() {
        return PassWord;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public void setPassWord(String PassWord) {
        this.PassWord = PassWord;
    }
    
 @Override 
    public String toString()
            
    {
    return UserName;
    }
}



