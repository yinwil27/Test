import CSVReader


class Truck:
    LeaveTime = 480
    CurrentTime = 480

    CSVReader.getDistance('4001 South 700 East', '1060 Dalton Ave S')

    def deliveryminutes(self):
        return CSVReader.getDistance('4001 South 700 East', '1060 Dalton Ave S') / self

    def currentminutes(self):
        return (CSVReader.getDistance('4001 South 700 East', '1060 Dalton Ave S') / self) + Truck.CurrentTime

    def Delivert(self, package):
        return print("package :" + CSVReader.PackageID + "was delivered at")
        CSVReader.Ride1.pop(1)

    print("Package took" + str(deliveryminutes(18)) + "to deliver")
    print("Package was delivered at" + str(currentminutes(1)) + "Time")
