import CSVReader
import HashMap
import Dictionary

''''
loop through RolodexAddressOnly
start from Hub
call getDistance function for each element n RolodexAddressonly
find distance
assign minimum distance  minDistance
find address for minDistance and deliver
repeat this for all addresses 
if address is not in current truck, skip
'''
Truck1 = []
h = HashMap.HashMap()
# for Truck1 in CSVReader.RolodexAddressOnly:
print("Package1's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '195 W Oakland Ave')))
print("Package13's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '2010 W 500 S')))
print("Package14's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '4300 S 1300 E')))
print("Package15's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E')))
print("Package16's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E')))
print("Package17's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '3148 S 1100 W')))
print("Package19's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '177 W Price Ave')))
print("Package30's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '300 State St')))
print("Package31's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '3365 S 900 W')))
print("Package34's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E')))
print("Package37's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '410 S State St')))
print("Package40's distance is: " + str(CSVReader.getDistance('4001 South 700 East', '380 W 2880 S')))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '195 W Oakland Ave'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '2010 W 500 S'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '4300 S 1300 E'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '3148 S 1100 W'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '300 State St'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '3365 S 900 W'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '4580 S 2300 E'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '410 S State St'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '380 W 2880 S'))
Truck1.append(CSVReader.getDistance('4001 South 700 East', '177 W Price Ave'))
minDistance1 = sorted(Truck1)
'''
#dictionary of all 40, array of truck
csvreadr.GD

# Reminder:ask about 10.9
'''

'''
def greedy(deliverylist, diction):
     while len(deliverylist) > 0:
        print('The closest address is: ' + (diction[deliverylist[0]]) +
              ', with a Distance of : ' + deliverylist.pop(0) + ' miles')
'''

'''print(CSVReader.getDistance(print(getDistance('4001 South 700 East', '1060 Dalton Ave S'))))'''


class Truck:
    CurrentTime = 0  # Current time, in hours
    LeaveTime = 0  # Time you left, in hours,
    TravelTime = 0  # Time it takes for you to travel with this package
    newdistance = 0
    listOfDeliveredItems = []
    # CurrentMilesTraveled = []
    miles = 0  # Miles traveled so far

    def __init__(self):
        self.package_list = []
        self.size = 6
        self.Location = '4001 South 700 East'
        self.LeaveTime = 0  # in hours,
        self.CurrentTime = 0  # in hours
        self.totalMiles = 0

    def odometer(self, totalMiles):
        odometerVariable = Truck.miles + totalMiles

    def currentTravel(miles):
        Truck.travel + Truck.newdistance

    def stopwatch(LeaveTime):
        LeaveTime + Truck.CurrentTime

    # Package ID

    def howLongDoesItTakeToDeliver(self):
        return print(str(float(newdistance) / 18.0) + 'hours to deliver')

    def deliver(self, packageID, h):
        package_list = h.get(packageID)
        addy = package_list[1]
        Truck.listOfDeliveredItems.append(addy)
        newdistance = CSVReader.getDistance(self.Location, addy)

        '''  Add odometer and stopwatch updates
        '''
        return print("package: " + package_list[0] + " was delivered at " + addy + " Distance of " + newdistance +
                     " it takes " + str(float(newdistance) / 18.0) + " hours.")


h = HashMap.HashMap()

h = CSVReader.HashMaker(h)
truckAmazon = Truck()
print(str(Truck.stopwatch(8.5)))
'''print(greedy(minDistance1, Dictionary.Trip1Dict))'''
truckAmazon.deliver('5', h)
