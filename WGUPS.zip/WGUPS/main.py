import csv
import CSVReader
import HashMap
import Truck

Truck.



'''
# Example of making predictions
from math import sqrt


# calculate the Euclidean distance between two vectors
def euclidean_distance(row1, row2):
    distance = 0.0
    for i in range(len(row1) - 1):
        distance += (row1[i] - row2[i]) ** 2
    return sqrt(distance)


# Locate the most similar neighbors
def get_neighbors(train, test_row, num_neighbors):
    distances = list()
    for train_row in train:
        dist = euclidean_distance(test_row, train_row)
        distances.append((train_row, dist))
    distances.sort(key=lambda tup: tup[1])
    neighbors = list()
    for i in range(num_neighbors):
        neighbors.append(distances[i][0])
    return neighbors


# Make a classification prediction with neighbors
def predict_classification(train, test_row, num_neighbors):
    neighbors = get_neighbors(train, test_row, num_neighbors)
    output_values = [row[-1] for row in neighbors]
    prediction = max(set(output_values), key=output_values.count)
    return prediction


# Test distance function
dataset = [[2.7810836, 2.550537003, 0],
           [1.465489372, 2.362125076, 0],
           [3.396561688, 4.400293529, 0],
           [1.38807019, 1.850220317, 0],
           [3.06407232, 3.005305973, 0],
           [7.627531214, 2.759262235, 1],
           [5.332441248, 2.088626775, 1],
           [6.922596716, 1.77106367, 1],
           [8.675418651, -0.242068655, 1],
           [7.673756466, 3.508563011, 1]]
prediction = predict_classification(dataset, dataset[0], 3)
print('Expected %d, Got %d.' % (dataset[0][-1], prediction))


'''
def dropOff1(packageCount):
    while packageCount > 0:
        print("dropoff")
        print(o)
        as_list = list(FirstTime)
        print("distance traveled:" + o)
        as_list.remove(o)
        packageCount -= 1


print(dropOff1(12))
'''
'''
SecondTime = CSVReader.Ride2
p = min(str(SecondTime))
for p in SecondTime:
    print("Ride2")
    print(p)

ThirdTime = CSVReader.Ride3
q = min(str(ThirdTime))
for q in ThirdTime:
    print("Ride3")
    print(q)

''
h.add("1", "195 W Oakland Ave	Salt Lake City	UT 84115")
h.add('2', '2530 S 500 E	Salt Lake City	UT	84106')
h.add('3', '233 Canyon Rd	Salt Lake City	UT	84103')
h.add('4', '380 W 2880 S	Salt Lake City	UT	84115')
h.add('5', '410 S State St	Salt Lake City	UT	84111')
h.add('6', '3060 Lester St	West Valley City	UT	84119')
h.add('7', '1330 2100 S	Salt Lake City	UT	84106')
h.add('8', '300 State St	Salt Lake City	UT	84103')
h.add('9', '410 S State St Salt Lake City UT 84111')
h.add('10', '600 E 900 South	Salt Lake City	UT	84105')
h.add('11', '2600 Taylorsville Blvd	Salt Lake City	UT	84118')
h.add('12', '3575 W Valley Central Station bus Loop	West Valley City	UT	84119')
h.add('13', '2010 W 500 S	Salt Lake City	UT	84104')
h.add('14', '4300 S 1300 E	Millcreek	UT	84117')
h.add('15', '4580 S 2300 E	Holladay	UT	84117')
h.add('16', '4580 S 2300 E	Holladay	UT	84117')
h.add('17', '3148 S 1100 W	Salt Lake City	UT	84119')
h.add('18', '1488 4800 S	Salt Lake City	UT	84123')
h.add('19', '177 W Price Ave	Salt Lake City	UT	84115')
h.add('20', '3595 Main St	Salt Lake City	UT	84115')
h.add('21', '3595 Main St	Salt Lake City	UT	84115')
h.add('22', '6351 South 900 East	Murray	UT	84121')
h.add('23', '5100 South 2700 West	Salt Lake City	UT	84118')
h.add('24', '5025 State St	Murray	UT	84107')
h.add('25', '5383 South 900 East #104	Salt Lake City	UT	84117')
h.add('26', '5383 South 900 East #104	Salt Lake City	UT	84117')
h.add('27', '1060 Dalton Ave S	Salt Lake City	UT	84104')
h.add('28', '2835 Main St	Salt Lake City	UT	84115')
h.add('29', '1330 2100 S	Salt Lake City	UT	84106')
h.add('30', '300 State St	Salt Lake City	UT	84103')
h.add('31', '3365 S 900 W	Salt Lake City	UT	84119')
h.add('32', '3365 S 900 W	Salt Lake City	UT	84119')
h.add('33', '2530 S 500 E	Salt Lake City	UT	84106')
h.add('34', '4580 S 2300 E	Holladay	UT	84117')
h.add('35', '1060 Dalton Ave S	Salt Lake City	UT	84104')
h.add('36', '2300 Parkway Blvd	West Valley City	UT	84119')
h.add('37', '410 S State St	Salt Lake City	UT	84111')
h.add('38', '410 S State St	Salt Lake City	UT	84111')
h.add('39', '2010 W 500 S	Salt Lake City	UT	84104')
h.add('40', '380 W 2880 S	Salt Lake City	UT	84115')
h.print()

# create an algorithm that checks everything for the shortest distance from current location. recount, go again,
# shortest distance, count, go again Using holistic approach
Ride1 = [h.get('1'), h.get('13'), h.get('14'), h.get('15'), h.get('16'), h.get('17'), h.get('19'), h.get('30'),
         h.get('31'), h.get('34'), h.get('37'), h.get('40')]  # 8 am
Ride2 = [h.get('3'), h.get('6'), h.get('18'), h.get('25'), h.get('36'), h.get('38'), h.get('32'), h.get('33'),
         h.get('35'), h.get('39')]  # 9:06 am
Ride3 = [h.get('2'), h.get('4'), h.get('5'), h.get('7'), h.get('8'), h.get('9'), h.get('10'), h.get('11'),
         h.get('21'), h.get('22'), h.get('23'), h.get('24'), h.get('26'), h.get('27'), h.get('28')]  # 1021am

print("Truck1")
print(Ride1)

print("Truck2")
print(Ride2)

print("Truck1, 2nd Ride")
print(Ride3)
'''
