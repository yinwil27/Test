# if statements

x = 38
y = 27

if x == 21:
    print("21 Savage")
elif x + 32 == 70:
    print("SleepyTime")
elif y == 27:
    print("27 Club")
else:
    print("You need a new plugin")

# fibonacci loops
WordList = ['zero', 'one', 'two', 'three']
n = 0
while n < 4:
    print(WordList[n])
    n += 1
# For Loop, use these over while loops
WordList2 = ['four', 'five', 'six', 'seven', 'eight']
o = 0
for o in WordList2:
    print(o)


# Functions
def funkyfresh(age):
    print(age)


funkyfresh(27)
print("Your Age is:" + str(funkyfresh(27)))

# dictionary

my_dict = {
    'N': 'No Problem',
    'Y': "You're Welcome",

}
print(my_dict)