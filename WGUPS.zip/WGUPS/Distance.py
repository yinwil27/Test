import csv
import csv

GPSMatrix = []
# Read in csv file that is the mapping of distances between locations
with open('DistanceNumbers.csv') as csvfile:
    readCSV2 = csv.reader(csvfile, delimiter=',')
    readCSV2 = list(readCSV2)
    for row in readCSV2:
        GPS = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11],
               row[12], row[13], row[14], row[15], row[16], row[17], row[18], row[19], row[20], row[21], row[22],
               row[23], row[24], row[25], row[26]]
        GPSMatrix.append(row)

'''    for row in readCSV:
        print("row")
        print(row)
        print(row[0])
        print(row[0], row[1],row[2])

        package = [row[1],row[2],row[3],row[4],row[5],row[6], row[7] ,row[8]]
        h.add(row[0], package)
        #PackageID.append(PackageID)
        #Address.append(Address)'''
# Read in csv file that is the names of all possible delivery locations

with open('DistanceApart.csv') as csv_name_file:
    readCSV3 = csv.reader(csv_name_file, delimiter=',')
    readCSV3 = list(readCSV3)
    for row in readCSV3:
        Book = [row[0], row[1], row[2]]

        GPSMatrix.append(row)
print(GPSMatrix)
