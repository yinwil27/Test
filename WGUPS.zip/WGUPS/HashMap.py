# Hash Map

class HashMap:
    def __init__(self):
        self.size = 6
        self.map = [None] * self.size

    def _get_hash(self, key):
        hash = 0
        for char in str(key):
            hash += ord(char)
        return hash % self.size

    def add(self, key, value):

        key_hash = self._get_hash(key)
        key_value = [key, value]

        if self.map[key_hash] is None:

            self.map[key_hash] = list([key_value])

            return True
        else:
            for pair in self.map[key_hash]:
                if pair[0] == key:
                    pair[1] = value
                    return True
            self.map[key_hash].append(key_value)
            return True

    def get(self, key):
        key_hash = self._get_hash(key)
        if self.map[key_hash] is not None:
            for pair in self.map[key_hash]:
                if pair[0] == key:
                    return pair[1]
        return None


    def delete(self, key):
        key_hash = self._get_hash(key)

        if self.map[key_hash] is None:
            return False
        for i in range (0, len(self.map[key_hash])):
            if self.map[key_hash][i][0] == key:
                self.map[key_hash].pop(i)
                return True

    def print(self):
        print('---DELIVERY---')
        for item in self.map:
            if item is not None:
                print(str(item))


'''
h = HashMap()
h.add("1","195 W Oakland Ave	Salt Lake City	UT 84115")
print(h.get('1'))

h.add('2','2530 S 500 E	Salt Lake City	UT	84106')
h.add('3','233 Canyon Rd	Salt Lake City	UT	84103')
h.add('4','380 W 2880 S	Salt Lake City	UT	84115')
h.add('5','410 S State St	Salt Lake City	UT	84111')
h.add('6','3060 Lester St	West Valley City	UT	84119')
h.add('7','1330 2100 S	Salt Lake City	UT	84106')
h.add('WGUPS Package File')

h.add('8','300 State St	Salt Lake City	UT	84103')
h.add('9','300 State St	Salt Lake City	UT	84103')
h.add('10','600 E 900 South	Salt Lake City	UT	84105')
h.add('11','2600 Taylorsville Blvd	Salt Lake City	UT	84118')
h.add('12','3575 W Valley Central Station bus Loop	West Valley City	UT	84119')
h.add('13','2010 W 500 S	Salt Lake City	UT	84104')
h.add('14','4300 S 1300 E	Millcreek	UT	84117')
h.add('15','4580 S 2300 E	Holladay	UT	84117')
h.add('16','4580 S 2300 E	Holladay	UT	84117')
h.add('17','3148 S 1100 W	Salt Lake City	UT	84119')
h.add('18','1488 4800 S	Salt Lake City	UT	84123')
h.add('19','177 W Price Ave	Salt Lake City	UT	84115')
h.add('20','3595 Main St	Salt Lake City	UT	84115')
h.add('21','3595 Main St	Salt Lake City	UT	84115')
h.add('22','6351 South 900 East	Murray	UT	84121')
h.add('23','5100 South 2700 West	Salt Lake City	UT	84118')
h.add('24','5025 State St	Murray	UT	84107')
h.add('25','5383 South 900 East #104	Salt Lake City	UT	84117')
h.add('26','5383 South 900 East #104	Salt Lake City	UT	84117')
h.add('27','1060 Dalton Ave S	Salt Lake City	UT	84104')
h.add('28','2835 Main St	Salt Lake City	UT	84115')
h.add('29','1330 2100 S	Salt Lake City	UT	84106')
h.add('30','300 State St	Salt Lake City	UT	84103')
h.add('31','3365 S 900 W	Salt Lake City	UT	84119')
h.add('32','3365 S 900 W	Salt Lake City	UT	84119')
h.add('33','2530 S 500 E	Salt Lake City	UT	84106')
h.add('34','4580 S 2300 E	Holladay	UT	84117')
h.add('35','1060 Dalton Ave S	Salt Lake City	UT	84104')
h.add('36','2300 Parkway Blvd	West Valley City	UT	84119')
h.add('37','410 S State St	Salt Lake City	UT	84111')
h.add('38','410 S State St	Salt Lake City	UT	84111')
h.add('39','2010 W 500 S	Salt Lake City	UT	84104')
h.add('40','380 W 2880 S	Salt Lake City	UT	84115')

h.print()


'''