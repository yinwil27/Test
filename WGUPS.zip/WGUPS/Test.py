import csv

TestMatrix = []
with open('Test.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    for row in readCSV:
        TestMatrix.append(row)

print(TestMatrix)
print(TestMatrix[1][1])
# How to find a specific element

# How to find minimum number in a list


MyList = [500, 50, 5000, 1000, 5, 25, 104]
minDistance = 10000  # highest number not in list
minIndex = 100
for n in Ride1:
    # print(n)
    GetDistance
    if n < minValue:
        minValue = n
        minIndex = MyList.index(n)

print(minValue, minIndex)


MyList = [500, 50, 5000, 1000, 5, 25, 104]
minValue = 10000  # highest number not in list
minIndex = 100
for n in MyList:
    # print(n)
    if n < minValue:
        minValue = n
        minIndex = MyList.index(n)

print(minValue, minIndex)
