import csv

TestMatrix = []
with open('Test.csv') as csvfile:
    readCSV = csv.reader(csvfile, delimiter=',')
    for row in readCSV:
        TestMatrix.append(row)

print(TestMatrix)
print(TestMatrix[1][1])
#How to find a specific element
