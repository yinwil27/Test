 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Wakiti
 */
public abstract class Appointment {
     private int appointmentid;
    private String name;
    private String title;
    private String description;
    private String location;
    private String type;
    private String startDateAndTime;
    private String endDateAndTime;
    private String address;
    private int postalCode;
    private int phoneNumber;    
     public ObservableList<Record> associatedRecords = FXCollections.observableArrayList();
    public Appointment(int appointmentid, String name, String address, int postalCode, int phoneNumber, String title, String description, String location, String type, String startDateAndTime, String endDateAndTime) {
        this.appointmentid = appointmentid;
        this.name = name;
        this.title = title;
        this.description= description;
        this.location = location;
        this.type = type;
        this.startDateAndTime =startDateAndTime;
        this.endDateAndTime = endDateAndTime;
        this.postalCode = postalCode;
        this.address = address;
        this.phoneNumber = phoneNumber;
    
}
    
    
    public int phoneNumber() {
    return phoneNumber;
    }
    public void setPhoneNumber(){
    this.phoneNumber= phoneNumber;}
    public int getPostalCode(){
    return postalCode;
    }
    public void setPostalCode() {
    this.postalCode =postalCode;
    }
    public String getAddress() {
    return address;
    }
    
    public void setAddress(){
    this.address = address;
    }
    
    public int getappointmentId() {
        return appointmentid;
    }

    /**
     * @param id the id to set
     */
    public void setappointmentId(int appointmentid) {
        this.appointmentid = appointmentid;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
    public String getTitle(){
    return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
    return description;
    }
    public void setDescription(String description) {
    this.description = description;
    }
    public String getLocation() {
    return location;
    }
    public void setLocation(String Location){
    this.location = location;
    }
    public String getType(){
    return type;
    }
    public void setType(String type) {
     this.type = type;
    }   
    public String getStartDateAndTime(){
    return startDateAndTime;
    }    
    public void setstartDateAndTime(String startDateAndTime){
    this.startDateAndTime =startDateAndTime;
    }   
    public String getEndDateAndTime(){
    return endDateAndTime;
    }    
    public void setEndDateAndTime(String EndDateAndTime){
    this.endDateAndTime =endDateAndTime;
    }    
    public void addAssociatedRecord(Record record) {
        associatedRecords.add(record);
    }
/**
     * deleteAssociatedRecord was created to power the remove Associated Record Button detailed description of a logical or runtime error that you corrected in the code and a detailed description of how you corrected it above the line of code you are referring to
*
•  a compatible feature suitable to your application that would extend functionality to the next version if you were to update the application : Java SE should work
     */
    public boolean deleteAssociatedRecord(Record record)
    {
        return associatedRecords.remove(record);
    }
public void setAssociatedRecord(ObservableList <Record> ap) {
        this.associatedRecords=ap;
    
    }
    /**
     *
     * @return
     */
    public ObservableList<Record> getAllAssociatedRecords() {
        return associatedRecords;
    }

}